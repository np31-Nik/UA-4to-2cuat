var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642284731.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-e61874e3-60fc-4d52-8da5-9a3621c7c97f" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Registro" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e61874e3-60fc-4d52-8da5-9a3621c7c97f-1680642284731.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Registro"   datasizewidth="238.3px" datasizeheight="73.0px" dataX="94.8" dataY="168.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Registro</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Crear cuenta"   datasizewidth="228.2px" datasizeheight="62.5px" dataX="99.9" dataY="765.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Crear cuenta</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="16.6px" datasizeheight="13.6px" dataX="31.4" dataY="55.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="16.637741088867188" height="13.631800651550293" viewBox="31.41406250000015 55.0 16.637741088867188 13.631800651550293" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-e6187" d="M31.41406250000015 61.82030010223389 C31.41406250000015 62.08399963378906 31.528322219848782 62.347700119018555 31.730462074279934 62.54100036621094 L37.53120183944717 68.33299922943115 C37.74220228195205 68.53519916534424 37.97070264816299 68.6318006515503 38.225602626800686 68.6318006515503 C38.77930212020889 68.6318006515503 39.18360185623184 68.23630046844482 39.18360185623184 67.70020008087158 C39.18360185623184 67.41890048980713 39.078102588653714 67.1815996170044 38.893502712249905 67.0059003829956 L36.91600275039688 65.0019006729126 L34.36718225479141 62.672800064086914 L36.41500234603897 62.79590034484863 L47.06740140914932 62.79590034484863 C47.64750242233291 62.79590034484863 48.05180311203018 62.39159965515137 48.05180311203018 61.82030010223389 C48.05180311203018 61.24020004272461 47.64750242233291 60.83590030670166 47.06740140914932 60.83590030670166 L36.41500234603897 60.83590030670166 L34.375972270965725 60.95899963378906 L36.91600275039688 58.629899978637695 L38.893502712249905 56.625969886779785 C39.078102588653714 56.4501895904541 39.18360185623184 56.212889671325684 39.18360185623184 55.93164014816284 C39.18360185623184 55.39549970626831 38.77930212020889 55.0 38.225602626800686 55.0 C37.97070264816299 55.0 37.73340272903457 55.0966796875 37.504902362823636 55.31640005111694 L31.730462074279934 61.090800285339355 C31.528322219848782 61.284199714660645 31.41406250000015 61.547800064086914 31.41406250000015 61.82030010223389 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-e6187" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext autofit firer click ie-background commentable non-processed" customid="Volver"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="55.4" dataY="52.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Volver</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="360.7px" datasizeheight="58.0px" dataX="33.4" dataY="300.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre completo"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="360.7px" datasizeheight="64.0px" dataX="33.4" dataY="474.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="DNI/NIF"/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="360.7px" datasizeheight="58.0px" dataX="33.4" dataY="387.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Email"/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="360.7px" datasizeheight="58.0px" dataX="33.8" dataY="567.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Fecha nacimiento"/></div></div>  </div></div></div>\
      <div id="s-Input_5" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="360.7px" datasizeheight="64.0px" dataX="33.4" dataY="654.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div>  </div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;