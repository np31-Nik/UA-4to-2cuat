var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642284731.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Login" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1680642284731.css" />\
      <div class="freeLayout">\
      <div id="s-Path_55" class="path firer commentable non-processed" customid="Person circle"   datasizewidth="172.2px" datasizeheight="161.2px" dataX="127.9" dataY="155.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="172.18458557128906" height="161.17579650878906" viewBox="127.90770983695968 155.0 172.18458557128906 161.17579650878906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_55-d1224" d="M213.95824721926022 316.17579078674294 C261.14462806391236 316.17579078674294 300.0922901630402 279.7006552528976 300.0922901630402 235.58784465251054 C300.0922901630402 191.4749579408321 261.061298588775 155.0 213.87491774412285 155.0 C166.7719476452275 155.0 127.90770983695968 191.4749579408321 127.90770983695968 235.58784465251054 C127.90770983695968 279.7006552528976 166.85517778960775 316.17579078674294 213.95824721926022 316.17579078674294 Z M213.95824721926022 262.55423587302903 C190.49003746453693 262.55423587302903 172.26455924991984 270.4260208150905 163.44313016297662 279.46655383418795 C152.12508119179358 268.00958879503213 145.21775127911658 252.57818514415922 145.21775127911658 235.58784465251054 C145.21775127911658 199.81431991636143 175.75984605100007 171.13310324507574 213.87491774412285 171.13310324507574 C252.0735988445166 171.13310324507574 282.7825331680514 199.81431991636143 282.86586264318873 235.58784465251054 C282.86586264318873 252.57818514415922 275.95843791478904 268.00958879503213 264.55714525412253 279.54457636467765 C255.73514727284322 270.4260208150905 237.509777419052 262.55423587302903 213.95824721926022 262.55423587302903 Z M213.95824721926022 249.77246923904767 C230.10334205719266 249.92853967045747 242.66926978470912 236.99070260506633 242.66926978470912 220.31161501117103 C242.66926978470912 204.5680704974785 230.02002161212414 191.39701152163383 213.95824721926022 191.39701152163383 C197.97979327146479 191.39701152163383 185.24720659367364 204.5680704974785 185.330536068811 220.31161501117103 C185.41385651387955 236.99070260506633 197.89646379632745 249.69443825174784 213.95824721926022 249.77246923904767 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_55-d1224" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Login"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="139.0" dataY="774.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Login</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="64.0" dataY="588.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Your entry"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Usuario"   datasizewidth="55.1px" datasizeheight="18.0px" dataX="64.0" dataY="439.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Usuario</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Contrase&ntilde;a"   datasizewidth="82.7px" datasizeheight="18.0px" dataX="64.0" dataY="558.6" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Contrase&ntilde;a</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="64.0" dataY="473.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Your entry"/></div></div>  </div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;