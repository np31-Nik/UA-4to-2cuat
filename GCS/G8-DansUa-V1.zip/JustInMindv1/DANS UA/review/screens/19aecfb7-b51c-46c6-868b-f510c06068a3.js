var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642284731.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-19aecfb7-b51c-46c6-868b-f510c06068a3" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="EditarHistorial" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/19aecfb7-b51c-46c6-868b-f510c06068a3-1680642284731.css" />\
      <div class="freeLayout">\
      <div id="s-Table_1" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="405.0px" datasizeheight="80.7px" dataX="11.3" dataY="226.0" originalwidth="403.99999999999864px" originalheight="79.66666666666674px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Cell_5" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="203.0px" datasizeheight="40.8px" dataX="0.0" dataY="0.0" originalwidth="201.9999999999994px" originalheight="39.83333333333337px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_5 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_7" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="203.0px" datasizeheight="40.8px" dataX="0.0" dataY="0.0" originalwidth="201.9999999999994px" originalheight="39.83333333333337px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_7 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_6" customid="Cell 2" class="cellcontainer firer ie-background non-processed"    datasizewidth="203.0px" datasizeheight="40.8px" dataX="0.0" dataY="0.0" originalwidth="201.9999999999994px" originalheight="39.83333333333337px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_6 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_8" customid="Cell 5" class="cellcontainer firer ie-background non-processed"    datasizewidth="203.0px" datasizeheight="40.8px" dataX="0.0" dataY="0.0" originalwidth="201.9999999999994px" originalheight="39.83333333333337px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_8 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Nombre"   datasizewidth="202.5px" datasizeheight="40.3px" dataX="11.3" dataY="226.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Nombre</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Irene Vargas Vargas"   datasizewidth="202.5px" datasizeheight="40.0px" dataX="213.8" dataY="226.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Irene Vargas Vargas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="DNI"   datasizewidth="202.5px" datasizeheight="40.3px" dataX="11.8" dataY="266.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">DNI</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="21581398P"   datasizewidth="202.5px" datasizeheight="40.3px" dataX="213.8" dataY="266.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">21581398P</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_2" class="table firer commentable non-processed" customid="Table 2"  datasizewidth="405.0px" datasizeheight="190.6px" dataX="11.3" dataY="306.7" originalwidth="403.99999999999875px" originalheight="189.5632618025754px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Cell_17" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="405.0px" datasizeheight="53.1px" dataX="0.0" dataY="0.0" originalwidth="403.99999999999875px" originalheight="52.141630901287584px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_17 Table_2" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_18" customid="Cell 6" class="cellcontainer firer ie-background non-processed"    datasizewidth="405.0px" datasizeheight="51.1px" dataX="0.0" dataY="0.0" originalwidth="403.99999999999875px" originalheight="50.13999999999999px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_18 Table_2" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_19" customid="Cell 7" class="cellcontainer firer ie-background non-processed"    datasizewidth="405.0px" datasizeheight="53.1px" dataX="0.0" dataY="0.0" originalwidth="403.99999999999875px" originalheight="52.141630901287584px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_19 Table_2" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_20" customid="Cell 8" class="cellcontainer firer ie-background non-processed"    datasizewidth="405.0px" datasizeheight="36.1px" dataX="0.0" dataY="0.0" originalwidth="403.99999999999875px" originalheight="35.14000000000002px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_20 Table_2" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Medicaci&oacute;n"   datasizewidth="405.0px" datasizeheight="54.8px" dataX="11.3" dataY="306.7" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Medicaci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Carisoprodo12.04.22 - 19."   datasizewidth="405.0px" datasizeheight="50.8px" dataX="12.0" dataY="361.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0"> Carisoprodo<br />12.04.22 - 19.04.22, 1 vez al dia</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="richtext manualfit firer ie-background commentable non-processed" customid="Observaciones"   datasizewidth="405.0px" datasizeheight="52.8px" dataX="11.5" dataY="410.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">Observaciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="richtext manualfit firer ie-background commentable non-processed" customid="Alergia a los gatos"   datasizewidth="405.0px" datasizeheight="31.8px" dataX="11.5" dataY="463.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0"> Alergia a los gatos</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Historial"   datasizewidth="295.8px" datasizeheight="118.0px" dataX="66.1" dataY="96.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Historial</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Add button" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="shapewrapper-s-Ellipse_1" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="388.0" dataY="323.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Subtraction_4" class="path firer click commentable non-processed" customid="Add icon"   datasizewidth="11.4px" datasizeheight="11.4px" dataX="393.3" dataY="328.1"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.934783935546875" height="11.888229370117188" viewBox="393.25 328.0558800134316 11.934783935546875 11.888229370117188" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_4-19aec" d="M399.2165832519531 328.8058876412563 C399.2171630859375 328.8058876412563 399.2177734375 328.8058876412563 399.2183532714844 328.8058876412563 C399.48138427734375 328.8058876412563 399.6956481933594 329.01919552785625 399.6956481933594 329.28200992367357 L399.6908874511719 333.52387771758265 L403.9565124511719 333.52387771758265 C404.22052001953125 333.52387771758265 404.4347839355469 333.73717041347714 404.4347839355469 334.0 C404.4347839355469 334.2618725720764 404.22052001953125 334.47612228241724 403.9565124511719 334.47612228241724 L399.6899108886719 334.47612228241724 L399.6841735839844 338.7189319000672 C399.6841735839844 338.9802272253347 399.4708557128906 339.19411235874367 399.2076721191406 339.19411235874367 C399.2070617675781 339.19411235874367 399.20648193359375 339.19411235874367 399.2059020996094 339.19411235874367 C398.9419250488281 339.19411235874367 398.7276611328125 338.98080447214363 398.7276611328125 338.7179900763264 L398.7333984375 334.47612228241724 L394.478271484375 334.47612228241724 C394.2142639160156 334.47612228241724 394.0 334.2618725720764 394.0 334.0 C394.0 333.73717041347714 394.2142639160156 333.52387771758265 394.478271484375 333.52387771758265 L398.7343444824219 333.52387771758265 L398.7391357421875 329.2810680999327 C398.7400817871094 329.0188309509243 398.9533996582031 328.8058876412563 399.2165832519531 328.8058876412563 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_4-19aec" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Add button" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="shapewrapper-s-Ellipse_2" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="388.0" dataY="425.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Subtraction_5" class="path firer click commentable non-processed" customid="Add icon"   datasizewidth="11.4px" datasizeheight="11.4px" dataX="393.2" dataY="430.4"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.934783935546875" height="11.888229370117188" viewBox="393.24999999999994 430.4495898699367 11.934783935546875 11.888229370117188" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_5-19aec" d="M399.21658325195307 431.1995974977614 C399.21716308593744 431.1995974977614 399.21777343749994 431.1995974977614 399.2183532714843 431.1995974977614 C399.4813842773437 431.1995974977614 399.6956481933593 431.41290538436135 399.6956481933593 431.67571978017867 L399.6908874511718 435.91758757408775 L403.9565124511718 435.91758757408775 C404.2205200195312 435.91758757408775 404.4347839355468 436.13088026998224 404.4347839355468 436.3937098565051 C404.4347839355468 436.6555824285815 404.2205200195312 436.86983213892233 403.9565124511718 436.86983213892233 L399.6899108886718 436.86983213892233 L399.6841735839843 441.1126417565723 C399.6841735839843 441.3739370818398 399.47085571289057 441.58782221524876 399.20767211914057 441.58782221524876 C399.20706176757807 441.58782221524876 399.2064819335937 441.58782221524876 399.2059020996093 441.58782221524876 C398.94192504882807 441.58782221524876 398.72766113281244 441.37451432864873 398.72766113281244 441.11169993283147 L398.73339843749994 436.86983213892233 L394.47827148437494 436.86983213892233 C394.21426391601557 436.86983213892233 393.99999999999994 436.6555824285815 393.99999999999994 436.3937098565051 C393.99999999999994 436.13088026998224 394.21426391601557 435.91758757408775 394.47827148437494 435.91758757408775 L398.7343444824218 435.91758757408775 L398.73913574218744 431.6747779564378 C398.7400817871093 431.4125408074294 398.95339965820307 431.1995974977614 399.21658325195307 431.1995974977614 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_5-19aec" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Delete button" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="shapewrapper-s-Ellipse_5" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="388.0" dataY="467.7" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_5)">\
                            <ellipse id="s-Ellipse_5" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_5" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_5_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Subtraction_8" class="path firer click commentable non-processed" customid="Delete icon"   datasizewidth="11.4px" datasizeheight="2.0px" dataX="393.3" dataY="477.9"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.934783935546875" height="2.452239990234375" viewBox="393.25 477.9311341846994 11.934783935546875 2.452239990234375" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_8-19aec" d="M394.478271484375 478.6811295695145 C394.5691446284962 478.6811295695145 403.9565124511719 478.6811295695145 403.9565124511719 478.6811295695145 C404.22052001953125 478.6811295695145 404.4347839355469 478.894422265409 404.4347839355469 479.15725185193185 C404.4347839355469 479.41912442400826 404.22052001953125 479.6333741343491 403.9565124511719 479.6333741343491 L394.478271484375 479.6333741343491 C394.2142639160156 479.6333741343491 394.0 479.41912442400826 394.0 479.15725185193185 C394.0 479.15725185193185 394.00730258610037 478.6811295695145 394.478271484375 478.6811295695145 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_8-19aec" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Delete button" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="shapewrapper-s-Ellipse_6" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="388.0" dataY="375.3" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_6)">\
                            <ellipse id="s-Ellipse_6" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_6" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_6_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Subtraction_9" class="path firer click commentable non-processed" customid="Delete icon"   datasizewidth="11.4px" datasizeheight="2.0px" dataX="393.3" dataY="385.6"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.934783935546875" height="2.452239990234375" viewBox="393.25 385.59780085136697 11.934783935546875 2.452239990234375" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_9-19aec" d="M394.478271484375 386.3477962361821 C394.5691446284962 386.3477962361821 403.9565124511719 386.3477962361821 403.9565124511719 386.3477962361821 C404.22052001953125 386.3477962361821 404.4347839355469 386.5610889320766 404.4347839355469 386.8239185185994 C404.4347839355469 387.08579109067585 404.22052001953125 387.30004080101673 403.9565124511719 387.30004080101673 L394.478271484375 387.30004080101673 C394.2142639160156 387.30004080101673 394.0 387.08579109067585 394.0 386.8239185185994 C394.0 386.8239185185994 394.00730258610037 386.3477962361821 394.478271484375 386.3477962361821 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_9-19aec" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="248.9px" datasizeheight="50.0px" dataX="89.5" dataY="719.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Guardar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="248.9px" datasizeheight="50.0px" dataX="89.5" dataY="806.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Cancelar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;