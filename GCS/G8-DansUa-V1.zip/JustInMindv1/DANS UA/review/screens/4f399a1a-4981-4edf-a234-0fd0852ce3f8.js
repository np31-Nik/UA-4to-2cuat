var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642284731.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-4f399a1a-4981-4edf-a234-0fd0852ce3f8" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="NuevoMedicamento" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/4f399a1a-4981-4edf-a234-0fd0852ce3f8-1680642284731.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Nueva medicaci&oacute;npara[Nomb"   datasizewidth="295.8px" datasizeheight="93.0px" dataX="66.1" dataY="96.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Nueva medicaci&oacute;n<br />para<br />[Nombre Paciente]</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="16.6px" datasizeheight="13.6px" dataX="31.4" dataY="55.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.637741088867188" height="13.631800651550293" viewBox="31.41406250000015 55.0 16.637741088867188 13.631800651550293" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-4f399" d="M31.41406250000015 61.82030010223389 C31.41406250000015 62.08399963378906 31.528322219848782 62.347700119018555 31.730462074279934 62.54100036621094 L37.53120183944717 68.33299922943115 C37.74220228195205 68.53519916534424 37.97070264816299 68.6318006515503 38.225602626800686 68.6318006515503 C38.77930212020889 68.6318006515503 39.18360185623184 68.23630046844482 39.18360185623184 67.70020008087158 C39.18360185623184 67.41890048980713 39.078102588653714 67.1815996170044 38.893502712249905 67.0059003829956 L36.91600275039688 65.0019006729126 L34.36718225479141 62.672800064086914 L36.41500234603897 62.79590034484863 L47.06740140914932 62.79590034484863 C47.64750242233291 62.79590034484863 48.05180311203018 62.39159965515137 48.05180311203018 61.82030010223389 C48.05180311203018 61.24020004272461 47.64750242233291 60.83590030670166 47.06740140914932 60.83590030670166 L36.41500234603897 60.83590030670166 L34.375972270965725 60.95899963378906 L36.91600275039688 58.629899978637695 L38.893502712249905 56.625969886779785 C39.078102588653714 56.4501895904541 39.18360185623184 56.212889671325684 39.18360185623184 55.93164014816284 C39.18360185623184 55.39549970626831 38.77930212020889 55.0 38.225602626800686 55.0 C37.97070264816299 55.0 37.73340272903457 55.0966796875 37.504902362823636 55.31640005111694 L31.730462074279934 61.090800285339355 C31.528322219848782 61.284199714660645 31.41406250000015 61.547800064086914 31.41406250000015 61.82030010223389 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-4f399" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer click ie-background commentable non-processed" customid="Volver"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="55.4" dataY="52.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Volver</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_1" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="357.7px" datasizeheight="185.9px" dataX="39.7" dataY="226.0" originalwidth="356.6993588606524px" originalheight="184.8633333333334px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Cell_11" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="51.9px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="50.93px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_11 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_12" customid="Cell 4" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="51.9px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="50.93px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_12 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_13" customid="Cell 2" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="31.0px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="30.000000000000004px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_13 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_14" customid="Cell 5" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="31.0px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="30.000000000000004px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_14 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_15" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="31.0px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="30.00000000000001px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_15 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_16" customid="Cell 6" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="31.0px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="30.00000000000001px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_16 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_17" customid="Cell 7" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="31.0px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="30.00000000000001px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_17 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_18" customid="Cell 8" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="31.0px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="30.00000000000001px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_18 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_19" customid="Cell 9" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="44.9px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="43.933333333333344px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_19 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_20" customid="Cell 10" class="cellcontainer firer ie-background non-processed"    datasizewidth="179.3px" datasizeheight="44.9px" dataX="0.0" dataY="0.0" originalwidth="178.34967943032626px" originalheight="43.933333333333344px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_20 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Nombre medicamento o acti"   datasizewidth="168.2px" datasizeheight="54.0px" dataX="45.8" dataY="225.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Nombre medicamento o actividad</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="228.0" dataY="252.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Fecha inicio"   datasizewidth="92.5px" datasizeheight="18.0px" dataX="79.0" dataY="284.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Fecha inicio</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="Fecha fin"   datasizewidth="70.2px" datasizeheight="18.0px" dataX="89.0" dataY="316.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Fecha fin</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Veces al dia"   datasizewidth="91.6px" datasizeheight="18.0px" dataX="78.3" dataY="343.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Veces al dia</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="richtext autofit firer ie-background commentable non-processed" customid="Detalles"   datasizewidth="61.4px" datasizeheight="18.0px" dataX="93.0" dataY="376.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">Detalles</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="richtext autofit firer ie-background commentable non-processed" customid="Paracetamol"   datasizewidth="89.8px" datasizeheight="18.0px" dataX="264.0" dataY="243.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">Paracetamol</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_10" class="richtext autofit firer ie-background commentable non-processed" customid="12.04.2022"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="268.9" dataY="284.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0">12.04.2022</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="richtext autofit firer ie-background commentable non-processed" customid="19.04.2022"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="268.9" dataY="316.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0">19.04.2022</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="richtext autofit firer ie-background commentable non-processed" customid="3"   datasizewidth="8.9px" datasizeheight="18.0px" dataX="304.5" dataY="343.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0">3</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_13" class="richtext manualfit firer ie-background commentable non-processed" customid="Tomar 3 paracetamol al di"   datasizewidth="171.0px" datasizeheight="36.0px" dataX="223.4" dataY="367.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_13_0">Tomar 3 paracetamol al dia, 1 cada 4 horas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="145.0px" datasizeheight="50.0px" dataX="141.5" dataY="473.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">A&ntilde;adir</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;