var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642284731.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-131fc3d7-919b-497b-be8b-e52d110a0992" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Configuracion" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/131fc3d7-919b-497b-be8b-e52d110a0992-1680642284731.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Configuraci&oacute;n"   datasizewidth="296.2px" datasizeheight="55.0px" dataX="65.9" dataY="164.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Configuraci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group 4" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Notificaciones"   datasizewidth="163.6px" datasizeheight="27.0px" dataX="36.4" dataY="270.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Notificaciones</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_8" class="inputIOS checkbox firer commentable non-processed checked" customid="Toggle"  datasizewidth="51.0px" datasizeheight="31.0px" dataX="256.0" dataY="268.0"   value="true"  checked="checked" tabindex="-1">\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Tama&ntilde;o de la fuente"   datasizewidth="246.8px" datasizeheight="30.0px" dataX="34.7" dataY="338.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Tama&ntilde;o de la fuente</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Peque&ntilde;a"   datasizewidth="96.0px" datasizeheight="43.0px" dataX="34.7" dataY="400.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">Peque&ntilde;a</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Media"   datasizewidth="96.0px" datasizeheight="43.0px" dataX="151.0" dataY="400.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_2_0">Media</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="button multiline manualfit firer commentable non-processed" customid="Grande"   datasizewidth="96.0px" datasizeheight="43.0px" dataX="266.0" dataY="400.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">Grande</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Volumen"   datasizewidth="114.6px" datasizeheight="27.0px" dataX="36.4" dataY="486.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">Volumen</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Table_1" class="table firer ie-background commentable non-processed" customid="Slider Volume"  datasizewidth="297.0px" datasizeheight="44.0px" dataX="36.4" dataY="533.0" originalwidth="297.0000000000001px" originalheight="44.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <table summary="">\
                <tbody>\
                  <tr>\
                    <td id="s-Cell_3" customid="Cell" class="cellcontainer firer ie-background non-processed"    datasizewidth="297.0px" datasizeheight="44.0px" dataX="0.0" dataY="0.0" originalwidth="297.0000000000001px" originalheight="44.0px" >\
                      <div class="cellContainerChild">\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <div class="borderLayer">\
                      	  <div class="layout scrollable">\
                      	    <div class="paddingLayer">\
                              <div class="center ghostHLayout">\
                              <table class="layout" summary="">\
                                <tr>\
                                  <td class="layout horizontal insertionpoint verticalalign Cell_3 Table_1" valign="middle" align="center" hSpacing="3" vSpacing="0"><div class="relativeLayoutWrapper s-Group_2 "><div class="relativeLayoutWrapperResponsive">\
                              <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Volume Down" datasizewidth="0.0px" datasizeheight="0.0px" >\
                                <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="32.0px" datasizeheight="38.0px" datasizewidthpx="32.0" datasizeheightpx="38.0" dataX="398.0" dataY="645.0" >\
                                  <div class="backgroundLayer">\
                                    <div class="colorLayer"></div>\
                                    <div class="imageLayer"></div>\
                                  </div>\
                                  <div class="borderLayer">\
                                    <div class="paddingLayer">\
                                      <div class="content">\
                                        <div class="valign">\
                                          <span id="rtr-s-Rectangle_1_0"></span>\
                                        </div>\
                                      </div>\
                                    </div>\
                                  </div>\
                                </div>\
                                <div id="s-Path_1" class="path firer commentable non-processed" customid="volume down Icon"   datasizewidth="10.8px" datasizeheight="15.8px" dataX="410.0" dataY="656.0"  >\
                                  <div class="borderLayer">\
                                  	<div class="imageViewport">\
                                    	<?xml version="1.0" encoding="UTF-8"?>\
                                    	<svg xmlns="http://www.w3.org/2000/svg" width="10.775419235229492" height="15.750009536743164" viewBox="410.0 656.0 10.775419235229492 15.750009536743164" preserveAspectRatio="none">\
                                    	  <g>\
                                    	    <defs>\
                                    	      <path id="s-Path_1-131fc" d="M419.6328206062317 671.750009059906 C420.292019367218 671.750009059906 420.77541971206665 671.2578101158142 420.77541971206665 670.607409954071 L420.77541971206665 657.1865196228027 C420.77541971206665 656.5273399353027 420.292019367218 656.0 419.6240200996399 656.0 C419.1758198738098 656.0 418.85062074661255 656.1845698356628 418.3672194480896 656.6503896713257 L414.69331979751587 660.0869097709656 C414.64061975479126 660.139639377594 414.5703196525574 660.166009426117 414.491219997406 660.166009426117 L412.0039095878601 660.166009426117 C410.71192026138306 660.166009426117 410.0 660.886709690094 410.0 662.2490096092224 L410.0 665.51850938797 C410.0 666.8808093070984 410.71192026138306 667.6015105247498 412.0039095878601 667.6015105247498 L414.491219997406 667.6015105247498 C414.5703196525574 667.6015105247498 414.64061975479126 667.6279101371765 414.69331979751587 667.68070936203 L418.3672194480896 671.1435103416443 C418.8066201210022 671.5654101371765 419.1758198738098 671.750009059906 419.6328206062317 671.750009059906 Z "></path>\
                                    	    </defs>\
                                    	    <g style="mix-blend-mode:normal">\
                                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-131fc" fill="#8E8E93" fill-opacity="1.0"></use>\
                                    	    </g>\
                                    	  </g>\
                                    	</svg>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                              </div></div><div id="s-Dynamic_Panel_1" class="percentage dynamicpanel firer commentable non-processed-percentage non-processed" customid="Slider-bar" datasizewidth="80.0%" datasizeheight="44.0px" dataX="36.0" dataY="0.0" >\
                                <div id="s-Panel_1" class="percentage panel default firer commentable non-processed-percentage non-processed" customid="Panel 2"  datasizewidth="80.0%" datasizeheight="44.0px" >\
                                  <div class="backgroundLayer">\
                                    <div class="colorLayer"></div>\
                                    <div class="imageLayer"></div>\
                                  </div>\
                                  <div class="borderLayer">\
                                  	<div class="layoutWrapper scrollable">\
                                  	  <div class="paddingLayer">\
                                        <div class="freeLayout">\
                                        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="170.0px" datasizeheight="2.5px" datasizewidthpx="170.0" datasizeheightpx="2.5" dataX="1.0" dataY="21.0" >\
                                          <div class="backgroundLayer">\
                                            <div class="colorLayer"></div>\
                                            <div class="imageLayer"></div>\
                                          </div>\
                                          <div class="borderLayer">\
                                            <div class="paddingLayer">\
                                              <div class="content">\
                                                <div class="valign">\
                                                  <span id="rtr-s-Rectangle_3_0"></span>\
                                                </div>\
                                              </div>\
                                            </div>\
                                          </div>\
                                        </div>\
                                        </div>\
\
                                      </div>\
                                    </div>\
                                  </div>\
                                </div>\
                              </div><div class="relativeLayoutWrapper s-Group_3 "><div class="relativeLayoutWrapperResponsive">\
                              <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Volume Up" datasizewidth="0.0px" datasizeheight="0.0px" >\
                                <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="38.0px" datasizeheight="38.0px" datasizewidthpx="38.0" datasizeheightpx="38.0" dataX="329.0" dataY="645.1" >\
                                  <div class="backgroundLayer">\
                                    <div class="colorLayer"></div>\
                                    <div class="imageLayer"></div>\
                                  </div>\
                                  <div class="borderLayer">\
                                    <div class="paddingLayer">\
                                      <div class="content">\
                                        <div class="valign">\
                                          <span id="rtr-s-Rectangle_4_0"></span>\
                                        </div>\
                                      </div>\
                                    </div>\
                                  </div>\
                                </div>\
                                <div id="s-Path_2" class="path firer commentable non-processed" customid="Volume Up Icon"   datasizewidth="24.7px" datasizeheight="17.6px" dataX="335.0" dataY="655.1"  >\
                                  <div class="borderLayer">\
                                  	<div class="imageViewport">\
                                    	<?xml version="1.0" encoding="UTF-8"?>\
                                    	<svg xmlns="http://www.w3.org/2000/svg" width="24.670940399169922" height="17.57712173461914" viewBox="334.9765381813054 655.0888060999787 24.670940399169922 17.57712173461914" preserveAspectRatio="none">\
                                    	  <g>\
                                    	    <defs>\
                                    	      <path id="s-Path_2-131fc" d="M355.98237860202835 672.5312904787934 C356.369078278542 672.7861904574311 356.8876787424092 672.6718906832612 357.16887915134475 672.2499889803803 C358.715778946877 669.9296898318207 359.6474786996846 667.0468906832612 359.6474786996846 663.8828901720917 C359.6474786996846 660.7099899722016 358.6981779336934 657.8359698725617 357.16887915134475 655.5068697405732 C356.8876787424092 655.0761999560273 356.369078278542 654.9707297755158 355.98237860202835 655.2256197405732 C355.5604788064961 655.4980797243988 355.4989782571797 656.0166301203644 355.78907835483597 656.4824499560273 C357.1337782144551 658.5302996111786 357.96867811679886 661.0703901720917 357.96867811679886 663.8828901720917 C357.96867811679886 666.6777901125824 357.1337782144551 669.2353901339447 355.78907835483597 671.2744907809174 C355.4989782571797 671.7402901125824 355.5604788064961 672.2587894869721 355.98237860202835 672.5312904787934 Z M344.60937845706985 671.7578892184174 C345.2684780359273 671.7578892184174 345.7518783807759 671.2656902743256 345.7518783807759 670.6152901125824 L345.7518783807759 657.1943697405732 C345.7518783807759 656.5351900530732 345.2684780359273 656.0078401041901 344.5917783975606 656.0078401041901 C344.1434780359273 656.0078401041901 343.8183780908589 656.192409939853 343.34367811679886 656.6582297755158 L339.66989815235183 660.0947603655732 C339.61715805530594 660.1474899722016 339.5468484163289 660.1738600207245 339.46774828434036 660.1738600207245 L336.9804383516316 660.1738600207245 C335.6796582937245 660.1738600207245 334.9765381813054 660.8945898486054 334.9765381813054 662.2568897677338 L334.9765381813054 665.5263895464814 C334.9765381813054 666.8886894656098 335.6796582937245 667.6093906832612 336.9804383516316 667.6093906832612 L339.46774828434036 667.6093906832612 C339.5468484163289 667.6093906832612 339.6083680391316 667.6357902956879 339.66989815235183 667.6884903384125 L343.34367811679886 671.1513905001557 C343.78317797184036 671.5732902956879 344.15227854251907 671.7578892184174 344.60937845706985 671.7578892184174 Z M352.4227777719502 670.1494907809174 C352.8270784616475 670.3954891634858 353.3192774057393 670.3076900912201 353.60057890415237 669.8945908022797 C354.74317800998733 668.2773899508393 355.41107809543655 666.1064896059906 355.41107809543655 663.8740896654999 C355.41107809543655 661.641589589206 354.7518774271016 659.4619497729218 353.60057890415237 657.8535499049103 C353.3192774057393 657.4404601527131 352.8270784616475 657.3437799883759 352.4227777719502 657.598659939853 C352.00097906589554 657.8623399210846 351.9393774271016 658.3896803332245 352.25587904453323 658.8554996920502 C353.1874777078633 660.226589627353 353.72357809543655 662.0107902956879 353.72357809543655 663.8740896654999 C353.72357809543655 665.7285894823945 353.17867910862014 667.5126900149262 352.25587904453323 668.8925899935639 C351.9481779336934 669.3583893252289 352.00097906589554 669.8769897890961 352.4227777719502 670.1494907809174 Z M348.8808780908589 667.7939896059906 C349.2587782144551 668.0400890780365 349.75097906589554 667.952190823642 350.0233789682393 667.5654892397797 C350.7352777719502 666.616289563266 351.15717756748245 665.2714895678437 351.15717756748245 663.8740896654999 C351.15717756748245 662.476589627353 350.7352777719502 661.1406902743256 350.0233789682393 660.1826500368988 C349.75097906589554 659.7959303332245 349.2587782144551 659.7080397082245 348.8808780908589 659.9629196597016 C348.4501777887349 660.2441896868622 348.3710781335835 660.7626900149262 348.7138782739644 661.2724899722016 C349.197278618813 661.9667896700776 349.46967756748245 662.8984903765595 349.46967756748245 663.8740896654999 C349.46967756748245 664.8496899081147 349.197278618813 665.7724899722016 348.7138782739644 666.4755901766694 C348.3710781335835 666.9853901339447 348.4501777887349 667.5038895083344 348.8808780908589 667.7939896059906 Z "></path>\
                                    	    </defs>\
                                    	    <g style="mix-blend-mode:normal">\
                                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-131fc" fill="#8E8E93" fill-opacity="1.0"></use>\
                                    	    </g>\
                                    	  </g>\
                                    	</svg>\
\
                                    </div>\
                                  </div>\
                                </div>\
                              </div>\
                              </div></div></td> \
                                </tr>\
                              </table>\
                              </div>\
\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Guardar"   datasizewidth="206.1px" datasizeheight="47.0px" dataX="111.9" dataY="783.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">Guardar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Cancelar"   datasizewidth="206.1px" datasizeheight="47.0px" dataX="111.9" dataY="841.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">Cancelar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;