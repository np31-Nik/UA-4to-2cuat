var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642284731.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Notificaciones" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a-1680642284731.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Notificaciones"   datasizewidth="311.3px" datasizeheight="57.0px" dataX="58.4" dataY="137.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Notificaciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_1" class="table firer commentable non-processed" customid="Table 1"  datasizewidth="398.4px" datasizeheight="364.0px" dataX="14.8" dataY="263.0" originalwidth="397.4062499999998px" originalheight="363.0px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Cell_4" customid="Cell 1" class="cellcontainer firer ie-background non-processed"    datasizewidth="398.4px" datasizeheight="122.0px" dataX="0.0" dataY="0.0" originalwidth="397.4062500000001px" originalheight="120.99999999999999px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_4 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_5" customid="Cell 2" class="cellcontainer firer ie-background non-processed"    datasizewidth="398.4px" datasizeheight="122.0px" dataX="0.0" dataY="0.0" originalwidth="397.4062500000001px" originalheight="120.99999999999999px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_5 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_6" customid="Cell 3" class="cellcontainer firer ie-background non-processed"    datasizewidth="398.4px" datasizeheight="122.0px" dataX="0.0" dataY="0.0" originalwidth="397.4062500000001px" originalheight="120.99999999999999px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_6 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext manualfit firer click ie-background commentable non-processed" customid="Mensaje de: Maria Milla A"   datasizewidth="398.4px" datasizeheight="162.0px" dataX="14.8" dataY="263.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Mensaje de: </span><span id="rtr-s-Paragraph_2_1">Maria Milla Avila<br /></span><span id="rtr-s-Paragraph_2_2">&quot;Urgente!!!&quot;<br /><br /></span><span id="rtr-s-Paragraph_2_3">Hace 2s<br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext manualfit firer click ie-background commentable non-processed" customid="Mensaje de: Ramon Bernabe"   datasizewidth="398.4px" datasizeheight="135.0px" dataX="14.8" dataY="386.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Mensaje de: </span><span id="rtr-s-Paragraph_3_1">Ramon Bernabeu Alves<br /></span><span id="rtr-s-Paragraph_3_2">&quot;Me duelen las piernas&quot;<br /><br /></span><span id="rtr-s-Paragraph_3_3">Hace 5m</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext manualfit firer click ie-background commentable non-processed" customid="Mensaje de: Santiago Moli"   datasizewidth="398.4px" datasizeheight="135.0px" dataX="14.8" dataY="508.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Mensaje de: </span><span id="rtr-s-Paragraph_4_1">Santiago Molina<br /></span><span id="rtr-s-Paragraph_4_2">&quot;La medicacion me esta afectando negativamente&quot;<br /></span><span id="rtr-s-Paragraph_4_3">Hace 20m</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="16.6px" datasizeheight="13.6px" dataX="37.0" dataY="88.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.637741088867188" height="13.631800651550293" viewBox="37.0 88.0 16.637741088867188 13.631800651550293" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-a1e4c" d="M37.0 94.82030010223389 C37.0 95.08399963378906 37.11425971984863 95.34770011901855 37.316399574279785 95.54100036621094 L43.11713933944702 101.33299922943115 C43.328139781951904 101.53519916534424 43.55664014816284 101.6318006515503 43.81154012680054 101.6318006515503 C44.36523962020874 101.6318006515503 44.76953935623169 101.23630046844482 44.76953935623169 100.70020008087158 C44.76953935623169 100.41890048980713 44.664040088653564 100.1815996170044 44.479440212249756 100.0059003829956 L42.50194025039673 98.0019006729126 L39.95311975479126 95.67280006408691 L42.00093984603882 95.79590034484863 L52.65333890914917 95.79590034484863 C53.233439922332764 95.79590034484863 53.63774061203003 95.39159965515137 53.63774061203003 94.82030010223389 C53.63774061203003 94.24020004272461 53.233439922332764 93.83590030670166 52.65333890914917 93.83590030670166 L42.00093984603882 93.83590030670166 L39.961909770965576 93.95899963378906 L42.50194025039673 91.6298999786377 L44.479440212249756 89.62596988677979 C44.664040088653564 89.4501895904541 44.76953935623169 89.21288967132568 44.76953935623169 88.93164014816284 C44.76953935623169 88.39549970626831 44.36523962020874 88.0 43.81154012680054 88.0 C43.55664014816284 88.0 43.319340229034424 88.0966796875 43.090839862823486 88.31640005111694 L37.316399574279785 94.09080028533936 C37.11425971984863 94.28419971466064 37.0 94.54780006408691 37.0 94.82030010223389 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-a1e4c" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer click ie-background commentable non-processed" customid="Volver"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="61.0" dataY="85.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Volver</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;