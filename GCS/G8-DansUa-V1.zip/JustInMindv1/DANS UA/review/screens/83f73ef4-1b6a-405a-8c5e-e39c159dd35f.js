var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642284731.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-83f73ef4-1b6a-405a-8c5e-e39c159dd35f" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="MensajeriaListado" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/83f73ef4-1b6a-405a-8c5e-e39c159dd35f-1680642284731.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Chat"   datasizewidth="285.3px" datasizeheight="85.0px" dataX="71.4" dataY="171.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Chat</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_16" class="group firer ie-background commentable non-processed" customid="Search Field" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input_15" class="text firer focusin focusout commentable non-processed" customid="Search Input"  datasizewidth="357.7px" datasizeheight="36.0px" dataX="29.2" dataY="319.1" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
        <div id="s-Path_123" class="path firer commentable non-processed" customid="Search icon"   datasizewidth="15.0px" datasizeheight="16.9px" dataX="36.3" dataY="329.1"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="14.999378204345703" height="16.91897964477539" viewBox="36.33069666634539 329.13253012048153 14.999378204345703 16.91897964477539" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_123-83f73" d="M42.52076159590337 342.9665092502728 C43.77139825547253 342.9665092502728 44.943372187558815 342.54460945474057 45.91864492140196 341.82391014443783 L49.36369003838046 345.68231048928646 C49.59180256010204 345.92840996133236 49.882828194757614 346.0515102420941 50.19747739778387 346.0515102420941 C50.85022526787371 346.0515102420941 51.33007558659277 345.4802097355023 51.33007558659277 344.75951042519955 C51.33007558659277 344.4255107914105 51.22778758383399 344.1003097568646 51.007550722839454 343.8542102848187 L47.58613088113687 340.013409045805 C48.29400496250558 338.88840999947934 48.710853409218714 337.5261100803509 48.710853409218714 336.0495103870526 C48.710853409218714 332.243859675993 45.92652058212901 329.13253012048153 42.52076159590337 329.13253012048153 C39.12292264994074 329.13253012048153 36.33069666634539 332.243859675993 36.33069666634539 336.0495103870526 C36.33069666634539 339.8552097355023 39.11505637719245 342.9665092502728 42.52076159590337 342.9665092502728 Z M42.52076159590337 341.12080993997006 C40.027444162037874 341.12080993997006 37.98244069260496 338.8356098209515 37.98244069260496 336.0495103870526 C37.98244069260496 333.2633899723187 40.027444162037874 330.9782299076214 42.52076159590337 330.9782299076214 C45.01416010776725 330.9782299076214 47.0591187709379 333.2633899723187 47.0591187709379 336.0495103870526 C47.0591187709379 338.8356098209515 45.01416010776725 341.12080993997006 42.52076159590337 341.12080993997006 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_123-83f73" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_113" class="path firer commentable non-processed" customid="Microphone icon"   datasizewidth="12.0px" datasizeheight="17.3px" dataX="363.9" dataY="329.1"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.0" height="17.269668579101562" viewBox="363.8677305896157 329.1325301204814 12.0 17.269668579101562" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_113-83f73" d="M369.8677484848036 340.3000847529988 C371.46201287825113 340.3000847529988 372.6399755508776 339.1063973231327 372.6399755508776 337.36291007082656 L372.6399755508776 332.0697137502476 C372.6399755508776 330.3262537667992 371.46201287825113 329.1325301204814 369.8677484848036 329.1325301204814 C368.273484091356 329.1325301204814 367.09552227088136 330.3262537667992 367.09552227088136 332.0697137502476 L367.09552227088136 337.36291007082656 C367.09552227088136 339.1063973231327 368.273484091356 340.3000847529988 369.8677484848036 340.3000847529988 Z M363.8677305896157 337.5435850006199 C363.8677305896157 340.7948415339613 366.02742241743726 343.0173574013829 369.13736406066147 343.3158031191 L369.13736406066147 344.9100666603958 L366.25516936073325 344.9100666603958 C365.83893751636003 344.9100666603958 365.4933856990682 345.23996359689585 365.4933856990682 345.65617839823295 C365.4933856990682 346.06452783841894 365.83893751636003 346.40219980797895 366.25516936073325 346.40219980797895 L373.4803540255798 346.40219980797895 C373.89656882691696 346.40219980797895 374.2421027490209 346.06452783841894 374.2421027490209 345.65617839823295 C374.2421027490209 345.23996359689585 373.89656882691696 344.9100666603958 373.4803540255798 344.9100666603958 L370.5981329089457 344.9100666603958 L370.5981329089457 343.3158031191 C373.7081188640637 343.0173574013829 375.8677305896157 340.7948415339613 375.8677305896157 337.5435850006199 L375.8677305896157 335.99641051586286 C375.8677305896157 335.5801965666775 375.53792227690326 335.2582519108126 375.1217091798697 335.2582519108126 C374.7054960828362 335.2582519108126 374.35987183264103 335.5801965666775 374.35987183264103 335.99641051586286 L374.35987183264103 337.4885428112942 C374.35987183264103 340.1665892078354 372.54579573349656 341.925802069533 369.8677484848036 341.925802069533 C367.1897020882624 341.925802069533 365.3755893465904 340.1665892078354 365.3755893465904 337.4885428112942 L365.3755893465904 335.99641051586286 C365.3755893465904 335.5801965666775 365.03789181247623 335.2582519108126 364.621659968103 335.2582519108126 C364.20542854980573 335.2582519108126 363.8677305896157 335.5801965666775 363.8677305896157 335.99641051586286 L363.8677305896157 337.5435850006199 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_113-83f73" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Subtraction_4" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.0px" datasizeheight="18.0px" dataX="361.2" dataY="328.1"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="361.1829583603017 328.13253012048204 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_4-83f73" d="M367.4409407061795 333.97319301259785 C367.54114001027983 333.97319301259785 367.6414142204138 334.0111997776128 367.7178433432277 334.08730030808596 L370.18012950666366 336.54413067902794 L372.6479587165762 334.08730030808596 C372.7243129333565 334.0112743494213 372.82448726877925 333.97326758440624 372.9246616042019 333.97326758440624 C373.02481097094665 333.97326758440624 373.1249603376915 334.0112743494213 373.20133952314967 334.08730030808596 C373.353523614476 334.2388053654872 373.354072925388 334.4861600539531 373.20133952314967 334.63821197128254 L370.73296100232506 337.09558920215284 L373.1952721344388 339.5535132929513 C373.34743125708735 339.7050183503526 373.34800553667725 339.95237303881834 373.1946978548489 340.10387809621955 C373.1183186693909 340.17990405488433 373.018169302646 340.2179108198993 372.91801993590116 340.2179108198993 C372.8178456004785 340.2179108198993 372.71767126505586 340.17990405488433 372.6413170482756 340.10387809621955 L370.17958019575156 337.64650086534937 L367.7178433432277 340.09726606254134 C367.64153906380295 340.17321744939767 367.54133975970257 340.2110999280654 367.44121536163544 340.2110999280654 C367.34089121414604 340.2110999280654 367.24061700401194 340.17308073441563 367.16446253665436 340.09726606254134 C367.01172913441593 339.94521414521193 367.01172913441593 339.6984063166743 367.16446253665436 339.5463543993448 L369.62674870009033 337.09504234222453 L367.16388825706423 334.6376651113543 C367.01172913441593 334.4850663340966 367.01172913441593 334.23824607692427 367.16501184756635 334.0867534481577 C367.24104147153486 334.0110630626308 367.34094115150145 333.97319301259785 367.4409407061795 333.97319301259785 Z M370.18302587329106 328.13253012048204 C365.2335098372746 328.13253012048204 361.16091873505167 332.2003104110396 361.1830909209577 337.1324401041376 C361.160993641085 342.0476171394591 365.2055449181137 346.1102892611412 370.14275139596384 346.13226308735 C370.15618454463214 346.13232523052363 370.1695927246227 346.1323500877931 370.18300090461327 346.1323500877931 C375.1324919719519 346.1323500877931 379.2050581054971 342.0645573686008 379.18291088826874 337.1324401041376 C379.2049831994636 332.2172630688161 375.1604568911128 328.1546033757687 370.22325041326263 328.1326171209252 C370.209842233272 328.1325549777515 370.1964340532817 328.13253012048204 370.18302587329106 328.13253012048204 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_4-83f73" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="400.0px" datasizeheight="120.0px" datasizewidthpx="400.0" datasizeheightpx="120.0" dataX="13.0" dataY="369.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"><br /> &nbsp; &nbsp; &nbsp;David Mart&iacute;nez Ruiz<br /> &nbsp; &nbsp; &nbsp;6456218F<br /><br /> &nbsp; &nbsp; &nbsp;Greetings. I am writing because I discovered a way<br /> &nbsp; &nbsp; &nbsp;to improve the taste of decaffeinated&hellip;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="400.0px" datasizeheight="120.0px" datasizewidthpx="400.0" datasizeheightpx="120.0" dataX="14.0" dataY="489.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"><br /> &nbsp; &nbsp; &nbsp;&Aacute;ngel Cardoso Parre&ntilde;o<br /> &nbsp; &nbsp; &nbsp;74562345T<br /><br /> &nbsp; &nbsp; &nbsp;Greetings. I am writing because I discovered a way<br /> &nbsp; &nbsp; &nbsp;to improve the taste of decaffeinated&hellip;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="400.0px" datasizeheight="121.0px" datasizewidthpx="400.0" datasizeheightpx="121.0" dataX="14.0" dataY="609.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"><br /> &nbsp; &nbsp; &nbsp;Irina Espinoza<br /> &nbsp; &nbsp; &nbsp;85190564L<br /><br /> &nbsp; &nbsp; &nbsp;Greetings. I am writing because I discovered a way<br /> &nbsp; &nbsp; &nbsp;to improve the taste of decaffeinated&hellip;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="16.6px" datasizeheight="13.6px" dataX="37.0" dataY="88.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.637741088867188" height="13.631800651550293" viewBox="37.0 88.0 16.637741088867188 13.631800651550293" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-83f73" d="M37.0 94.82030010223389 C37.0 95.08399963378906 37.11425971984863 95.34770011901855 37.316399574279785 95.54100036621094 L43.11713933944702 101.33299922943115 C43.328139781951904 101.53519916534424 43.55664014816284 101.6318006515503 43.81154012680054 101.6318006515503 C44.36523962020874 101.6318006515503 44.76953935623169 101.23630046844482 44.76953935623169 100.70020008087158 C44.76953935623169 100.41890048980713 44.664040088653564 100.1815996170044 44.479440212249756 100.0059003829956 L42.50194025039673 98.0019006729126 L39.95311975479126 95.67280006408691 L42.00093984603882 95.79590034484863 L52.65333890914917 95.79590034484863 C53.233439922332764 95.79590034484863 53.63774061203003 95.39159965515137 53.63774061203003 94.82030010223389 C53.63774061203003 94.24020004272461 53.233439922332764 93.83590030670166 52.65333890914917 93.83590030670166 L42.00093984603882 93.83590030670166 L39.961909770965576 93.95899963378906 L42.50194025039673 91.6298999786377 L44.479440212249756 89.62596988677979 C44.664040088653564 89.4501895904541 44.76953935623169 89.21288967132568 44.76953935623169 88.93164014816284 C44.76953935623169 88.39549970626831 44.36523962020874 88.0 43.81154012680054 88.0 C43.55664014816284 88.0 43.319340229034424 88.0966796875 43.090839862823486 88.31640005111694 L37.316399574279785 94.09080028533936 C37.11425971984863 94.28419971466064 37.0 94.54780006408691 37.0 94.82030010223389 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-83f73" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer click ie-background commentable non-processed" customid="Volver"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="61.0" dataY="85.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Volver</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;