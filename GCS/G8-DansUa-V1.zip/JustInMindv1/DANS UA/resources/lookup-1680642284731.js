(function(window, undefined) {
  var dictionary = {
    "83f73ef4-1b6a-405a-8c5e-e39c159dd35f": "MensajeriaListado",
    "e61874e3-60fc-4d52-8da5-9a3621c7c97f": "Registro",
    "19aecfb7-b51c-46c6-868b-f510c06068a3": "EditarHistorial",
    "a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a": "Notificaciones",
    "e2680dfb-bb30-4c2e-b9a7-d392da4634f5": "Mensajeria",
    "4f399a1a-4981-4edf-a234-0fd0852ce3f8": "NuevoMedicamento",
    "901dbc10-3eaf-4dc1-b11b-40845f399b90": "Listado",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login",
    "dfeda26a-9ef7-453a-916d-f06e0c7773ed": "Menu",
    "97c5eac1-0190-431e-be71-cd1c48934a1f": "VerHistorial",
    "131fc3d7-919b-497b-be8b-e52d110a0992": "Configuracion",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);