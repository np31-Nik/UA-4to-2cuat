(function(window, undefined) {

  var jimLinks = {
    "83f73ef4-1b6a-405a-8c5e-e39c159dd35f" : {
      "Rectangle_1" : [
        "e2680dfb-bb30-4c2e-b9a7-d392da4634f5"
      ],
      "Rectangle_2" : [
        "e2680dfb-bb30-4c2e-b9a7-d392da4634f5"
      ],
      "Rectangle_3" : [
        "e2680dfb-bb30-4c2e-b9a7-d392da4634f5"
      ],
      "Path_5" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Paragraph_2" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ]
    },
    "e61874e3-60fc-4d52-8da5-9a3621c7c97f" : {
      "Button_6" : [
        "901dbc10-3eaf-4dc1-b11b-40845f399b90"
      ],
      "Path_1" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed",
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Paragraph_2" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed",
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ]
    },
    "19aecfb7-b51c-46c6-868b-f510c06068a3" : {
      "Ellipse_1" : [
        "4f399a1a-4981-4edf-a234-0fd0852ce3f8"
      ],
      "Subtraction_4" : [
        "4f399a1a-4981-4edf-a234-0fd0852ce3f8"
      ],
      "Button_1" : [
        "97c5eac1-0190-431e-be71-cd1c48934a1f"
      ],
      "Button_2" : [
        "97c5eac1-0190-431e-be71-cd1c48934a1f"
      ]
    },
    "a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a" : {
      "Paragraph_2" : [
        "e2680dfb-bb30-4c2e-b9a7-d392da4634f5"
      ],
      "Paragraph_3" : [
        "e2680dfb-bb30-4c2e-b9a7-d392da4634f5"
      ],
      "Paragraph_4" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Path_1" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Paragraph_5" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ]
    },
    "e2680dfb-bb30-4c2e-b9a7-d392da4634f5" : {
      "Path_1" : [
        "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"
      ],
      "Paragraph_2" : [
        "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"
      ]
    },
    "4f399a1a-4981-4edf-a234-0fd0852ce3f8" : {
      "Path_1" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Paragraph_2" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Button_1" : [
        "97c5eac1-0190-431e-be71-cd1c48934a1f"
      ]
    },
    "901dbc10-3eaf-4dc1-b11b-40845f399b90" : {
      "Rectangle_1" : [
        "97c5eac1-0190-431e-be71-cd1c48934a1f"
      ],
      "Rectangle_2" : [
        "97c5eac1-0190-431e-be71-cd1c48934a1f"
      ],
      "Rectangle_3" : [
        "97c5eac1-0190-431e-be71-cd1c48934a1f"
      ],
      "Path_5" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Paragraph_2" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ]
    },
    "dfeda26a-9ef7-453a-916d-f06e0c7773ed" : {
      "Button_1" : [
        "901dbc10-3eaf-4dc1-b11b-40845f399b90"
      ],
      "Button_3" : [
        "e61874e3-60fc-4d52-8da5-9a3621c7c97f"
      ],
      "Button_5" : [
        "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"
      ],
      "Button_7" : [
        "a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a"
      ],
      "Path_30" : [
        "131fc3d7-919b-497b-be8b-e52d110a0992"
      ]
    },
    "97c5eac1-0190-431e-be71-cd1c48934a1f" : {
      "Button_1" : [
        "19aecfb7-b51c-46c6-868b-f510c06068a3"
      ],
      "Path_1" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Paragraph_12" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Button_2" : [
        "e2680dfb-bb30-4c2e-b9a7-d392da4634f5"
      ]
    },
    "131fc3d7-919b-497b-be8b-e52d110a0992" : {
      "Button_4" : [
        "dfeda26a-9ef7-453a-916d-f06e0c7773ed"
      ],
      "Button_5" : [
        "131fc3d7-919b-497b-be8b-e52d110a0992"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);