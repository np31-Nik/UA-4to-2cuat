	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Input_15", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_123", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_113", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_113", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Subtraction_4", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_5", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "83f73ef4-1b6a-405a-8c5e-e39c159dd35f"]] = ["Arrow left", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_1", "e61874e3-60fc-4d52-8da5-9a3621c7c97f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "e61874e3-60fc-4d52-8da5-9a3621c7c97f"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Add", "s-Group_1"]; 

	widgets.descriptionMap[["s-Subtraction_4", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Add", "s-Group_1"]; 

	widgets.descriptionMap[["s-Ellipse_2", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Add", "s-Group_2"]; 

	widgets.descriptionMap[["s-Subtraction_5", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_5", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Add", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_5", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_5", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Delete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Subtraction_8", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_8", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Delete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Ellipse_6", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Delete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Subtraction_9", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_9", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Delete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Button_1", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "19aecfb7-b51c-46c6-868b-f510c06068a3"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_1", "a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_1", "e2680dfb-bb30-4c2e-b9a7-d392da4634f5"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "e2680dfb-bb30-4c2e-b9a7-d392da4634f5"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_1", "4f399a1a-4981-4edf-a234-0fd0852ce3f8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "4f399a1a-4981-4edf-a234-0fd0852ce3f8"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Button_1", "4f399a1a-4981-4edf-a234-0fd0852ce3f8"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "4f399a1a-4981-4edf-a234-0fd0852ce3f8"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Input_15", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_123", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ""; 

			widgets.rootWidgetMap[["s-Path_123", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_113", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ""; 

			widgets.rootWidgetMap[["s-Path_113", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Subtraction_4", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_4", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ["Search", "s-Group_16"]; 

	widgets.descriptionMap[["s-Path_5", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "901dbc10-3eaf-4dc1-b11b-40845f399b90"]] = ["Arrow left", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_55", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_55", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Person circle", "s-Path_55"]; 

	widgets.descriptionMap[["s-Path_35", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ""; 

			widgets.rootWidgetMap[["s-Path_35", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ["Persons", "s-Path_35"]; 

	widgets.descriptionMap[["s-Path_37", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ""; 

			widgets.rootWidgetMap[["s-Path_37", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ["Person plus", "s-Path_37"]; 

	widgets.descriptionMap[["s-Path_132", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ""; 

			widgets.rootWidgetMap[["s-Path_132", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ["Bubble text", "s-Path_132"]; 

	widgets.descriptionMap[["s-Path_91", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ""; 

			widgets.rootWidgetMap[["s-Path_91", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ["Bell", "s-Path_91"]; 

	widgets.descriptionMap[["s-Path_30", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ""; 

			widgets.rootWidgetMap[["s-Path_30", "dfeda26a-9ef7-453a-916d-f06e0c7773ed"]] = ["Gear", "s-Path_30"]; 

	widgets.descriptionMap[["s-Button_1", "97c5eac1-0190-431e-be71-cd1c48934a1f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "97c5eac1-0190-431e-be71-cd1c48934a1f"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "97c5eac1-0190-431e-be71-cd1c48934a1f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "97c5eac1-0190-431e-be71-cd1c48934a1f"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Input_8", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ["Toggle", "s-Input_8"]; 

	widgets.descriptionMap[["s-Rectangle_1", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ["Slider volume", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_1", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ["Slider volume", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ["Slider volume", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ["Slider volume", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ["Slider volume", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_2", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ["Slider volume", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "131fc3d7-919b-497b-be8b-e52d110a0992"]] = ["Slider volume", "s-Table_1"]; 

	