var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642006796.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Notificaciones" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/a1e4cbcf-0db1-4b8b-9b63-feeda09dae6a-1680642006796.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Notificaciones"   datasizewidth="177.7px" datasizeheight="29.0px" dataX="125.1" dataY="55.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Notificaciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext manualfit firer click ie-background commentable non-processed" customid="Maria Milla AvilaUrgente!"   datasizewidth="398.4px" datasizeheight="114.0px" dataX="14.3" dataY="116.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Maria Milla Avila<br /></span><span id="rtr-s-Paragraph_2_1">Urgente!!!<br /><br /></span><span id="rtr-s-Paragraph_2_2">Hace 2s</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext manualfit firer click ie-background commentable non-processed" customid="Ramon Bernabeu AlvesMe du"   datasizewidth="398.4px" datasizeheight="111.0px" dataX="15.0" dataY="241.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Ramon Bernabeu Alves<br /></span><span id="rtr-s-Paragraph_3_1">Me duelen las piernas<br /><br /></span><span id="rtr-s-Paragraph_3_2">Hace 5m</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext manualfit firer click ie-background commentable non-processed" customid="Santiago MolinaLa medicac"   datasizewidth="398.4px" datasizeheight="111.0px" dataX="14.8" dataY="361.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Santiago Molina<br /></span><span id="rtr-s-Paragraph_4_1">La medicacion me esta afectando...<br /><br /></span><span id="rtr-s-Paragraph_4_2">Hace 20m</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="16.6px" datasizeheight="13.6px" dataX="33.0" dataY="54.2"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="16.637741088867188" height="13.631800651550293" viewBox="33.0 54.184099674224946 16.637741088867188 13.631800651550293" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-a1e4c" d="M33.0 61.00439977645883 C33.0 61.26809930801401 33.11425971984863 61.5317997932435 33.316399574279785 61.72510004043588 L39.11713933944702 67.51709890365609 C39.328139781951904 67.71929883956918 39.55664014816284 67.81590032577523 39.81154012680054 67.81590032577523 C40.36523962020874 67.81590032577523 40.76953935623169 67.42040014266976 40.76953935623169 66.88429975509652 C40.76953935623169 66.60300016403207 40.664040088653564 66.36569929122933 40.479440212249756 66.19000005722054 L38.50194025039673 64.18600034713754 L35.95311975479126 61.85689973831186 L38.00093984603882 61.98000001907358 L48.65333890914917 61.98000001907358 C49.233439922332764 61.98000001907358 49.63774061203003 61.57569932937631 49.63774061203003 61.00439977645883 C49.63774061203003 60.424299716949555 49.233439922332764 60.019999980926606 48.65333890914917 60.019999980926606 L38.00093984603882 60.019999980926606 L35.961909770965576 60.14309930801401 L38.50194025039673 57.81399965286264 L40.479440212249756 55.81006956100473 C40.664040088653564 55.63428926467905 40.76953935623169 55.39698934555063 40.76953935623169 55.11573982238779 C40.76953935623169 54.579599380493256 40.36523962020874 54.184099674224946 39.81154012680054 54.184099674224946 C39.55664014816284 54.184099674224946 39.319340229034424 54.280779361724946 39.090839862823486 54.50049972534189 L33.316399574279785 60.2748999595643 C33.11425971984863 60.46829938888559 33.0 60.73189973831186 33.0 61.00439977645883 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-a1e4c" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer click ie-background commentable non-processed" customid="Volver"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="61.0" dataY="52.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Volver</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;