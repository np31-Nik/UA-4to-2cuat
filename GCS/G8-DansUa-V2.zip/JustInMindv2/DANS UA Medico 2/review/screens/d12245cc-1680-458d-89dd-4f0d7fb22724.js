var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642006796.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Login" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1680642006796.css" />\
      <div class="freeLayout">\
      <div id="s-Path_55" class="path firer commentable non-processed" customid="Person circle"   datasizewidth="172.2px" datasizeheight="161.2px" dataX="128.0" dataY="219.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="172.18458557128906" height="161.17579650878906" viewBox="128.0 219.0 172.18458557128906 161.17579650878906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_55-d1224" d="M214.05053738230052 380.17579078674294 C261.23691822695264 380.17579078674294 300.18458032608055 343.7006552528976 300.18458032608055 299.5878446525105 C300.18458032608055 255.4749579408321 261.1535887518153 219.0 213.96720790716316 219.0 C166.86423780826783 219.0 128.0 255.4749579408321 128.0 299.5878446525105 C128.0 343.7006552528976 166.94746795264808 380.17579078674294 214.05053738230052 380.17579078674294 Z M214.05053738230052 326.55423587302903 C190.58232762757723 326.55423587302903 172.35684941296014 334.4260208150905 163.53542032601692 343.46655383418795 C152.21737135483392 332.00958879503213 145.31004144215692 316.5781851441592 145.31004144215692 299.5878446525105 C145.31004144215692 263.8143199163614 175.8521362140404 235.13310324507574 213.96720790716316 235.13310324507574 C252.16588900755693 235.13310324507574 282.87482333109165 263.8143199163614 282.958152806229 299.5878446525105 C282.958152806229 316.5781851441592 276.0507280778294 332.00958879503213 264.64943541716286 343.54457636467765 C255.82743743588352 334.4260208150905 237.60206758209233 326.55423587302903 214.05053738230052 326.55423587302903 Z M214.05053738230052 313.77246923904767 C230.195632220233 313.92853967045744 242.76155994774942 300.9907026050663 242.76155994774942 284.31161501117106 C242.76155994774942 268.56807049747846 230.11231177516447 255.39701152163383 214.05053738230052 255.39701152163383 C198.0720834345051 255.39701152163383 185.33949675671397 268.56807049747846 185.42282623185133 284.31161501117106 C185.50614667691985 300.9907026050663 197.98875395936776 313.69443825174784 214.05053738230052 313.77246923904767 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_55-d1224" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Login"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="139.0" dataY="774.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Login</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="64.0" dataY="594.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Your entry"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Usuario"   datasizewidth="72.4px" datasizeheight="24.0px" dataX="64.0" dataY="439.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Usuario</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Contrase&ntilde;a"   datasizewidth="108.6px" datasizeheight="24.0px" dataX="64.0" dataY="558.6" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Contrase&ntilde;a</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="64.0" dataY="482.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Your entry"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="DANS UA"   datasizewidth="284.5px" datasizeheight="73.0px" dataX="71.7" dataY="125.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">DANS UA</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;