var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642006796.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-19aecfb7-b51c-46c6-868b-f510c06068a3" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="EditarHistorial" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/19aecfb7-b51c-46c6-868b-f510c06068a3-1680642006796.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Historial"   datasizewidth="295.8px" datasizeheight="118.0px" dataX="66.1" dataY="96.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Historial</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Add button" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="shapewrapper-s-Ellipse_1" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="106.0" dataY="409.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Subtraction_4" class="path firer click commentable non-processed" customid="Add icon"   datasizewidth="11.4px" datasizeheight="11.4px" dataX="111.3" dataY="414.1"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.934783935546875" height="11.888229370117188" viewBox="111.25 414.0558800134316 11.934783935546875 11.888229370117188" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_4-19aec" d="M117.21658325195312 414.8058876412563 C117.2171630859375 414.8058876412563 117.2177734375 414.8058876412563 117.21835327148438 414.8058876412563 C117.48138427734375 414.8058876412563 117.69564819335938 415.01919552785625 117.69564819335938 415.28200992367357 L117.69088745117188 419.52387771758265 L121.95651245117188 419.52387771758265 C122.22052001953125 419.52387771758265 122.43478393554688 419.73717041347714 122.43478393554688 420.0 C122.43478393554688 420.2618725720764 122.22052001953125 420.47612228241724 121.95651245117188 420.47612228241724 L117.68991088867188 420.47612228241724 L117.68417358398438 424.7189319000672 C117.68417358398438 424.9802272253347 117.47085571289062 425.19411235874367 117.20767211914062 425.19411235874367 C117.20706176757812 425.19411235874367 117.20648193359375 425.19411235874367 117.20590209960938 425.19411235874367 C116.94192504882812 425.19411235874367 116.7276611328125 424.98080447214363 116.7276611328125 424.7179900763264 L116.7333984375 420.47612228241724 L112.478271484375 420.47612228241724 C112.21426391601562 420.47612228241724 112.0 420.2618725720764 112.0 420.0 C112.0 419.73717041347714 112.21426391601562 419.52387771758265 112.478271484375 419.52387771758265 L116.73434448242188 419.52387771758265 L116.7391357421875 415.2810680999327 C116.74008178710938 415.0188309509243 116.95339965820312 414.8058876412563 117.21658325195312 414.8058876412563 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_4-19aec" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Add button" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="shapewrapper-s-Ellipse_2" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="132.0" dataY="556.4" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Subtraction_5" class="path firer click commentable non-processed" customid="Add icon"   datasizewidth="11.4px" datasizeheight="11.4px" dataX="137.2" dataY="561.4"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.934783935546875" height="11.888229370117188" viewBox="137.24999999999994 561.4495898699367 11.934783935546875 11.888229370117188" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_5-19aec" d="M143.21658325195307 562.1995974977614 C143.21716308593744 562.1995974977614 143.21777343749994 562.1995974977614 143.21835327148432 562.1995974977614 C143.4813842773437 562.1995974977614 143.69564819335932 562.4129053843614 143.69564819335932 562.6757197801787 L143.69088745117182 566.9175875740877 L147.95651245117182 566.9175875740877 C148.2205200195312 566.9175875740877 148.43478393554682 567.1308802699823 148.43478393554682 567.3937098565051 C148.43478393554682 567.6555824285815 148.2205200195312 567.8698321389223 147.95651245117182 567.8698321389223 L143.68991088867182 567.8698321389223 L143.68417358398432 572.1126417565723 C143.68417358398432 572.3739370818398 143.47085571289057 572.5878222152487 143.20767211914057 572.5878222152487 C143.20706176757807 572.5878222152487 143.2064819335937 572.5878222152487 143.20590209960932 572.5878222152487 C142.94192504882807 572.5878222152487 142.72766113281244 572.3745143286487 142.72766113281244 572.1116999328315 L142.73339843749994 567.8698321389223 L138.47827148437494 567.8698321389223 C138.21426391601557 567.8698321389223 137.99999999999994 567.6555824285815 137.99999999999994 567.3937098565051 C137.99999999999994 567.1308802699823 138.21426391601557 566.9175875740877 138.47827148437494 566.9175875740877 L142.73434448242182 566.9175875740877 L142.73913574218744 562.6747779564378 C142.74008178710932 562.4125408074294 142.95339965820307 562.1995974977614 143.21658325195307 562.1995974977614 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_5-19aec" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Delete button" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="shapewrapper-s-Ellipse_5" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="165.0" dataY="556.7" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_5)">\
                            <ellipse id="s-Ellipse_5" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_5" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_5_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Subtraction_8" class="path firer click commentable non-processed" customid="Delete icon"   datasizewidth="11.4px" datasizeheight="2.0px" dataX="170.3" dataY="566.9"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.934783935546875" height="2.452239990234375" viewBox="170.25 566.9311341846994 11.934783935546875 2.452239990234375" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_8-19aec" d="M171.478271484375 567.6811295695145 C171.5691446284962 567.6811295695145 180.95651245117188 567.6811295695145 180.95651245117188 567.6811295695145 C181.22052001953125 567.6811295695145 181.43478393554688 567.894422265409 181.43478393554688 568.1572518519318 C181.43478393554688 568.4191244240083 181.22052001953125 568.6333741343491 180.95651245117188 568.6333741343491 L171.478271484375 568.6333741343491 C171.21426391601562 568.6333741343491 171.0 568.4191244240083 171.0 568.1572518519318 C171.0 568.1572518519318 171.00730258610037 567.6811295695145 171.478271484375 567.6811295695145 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_8-19aec" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Delete button" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="shapewrapper-s-Ellipse_6" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="22.0px" datasizeheight="22.0px" datasizewidthpx="22.0" datasizeheightpx="22.0" dataX="143.0" dataY="409.3" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_6)">\
                            <ellipse id="s-Ellipse_6" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                            <ellipse cx="11.0" cy="11.0" rx="11.0" ry="11.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_6" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_6_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Subtraction_9" class="path firer click commentable non-processed" customid="Delete icon"   datasizewidth="11.4px" datasizeheight="2.0px" dataX="148.3" dataY="419.6"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="11.934783935546875" height="2.452239990234375" viewBox="148.25 419.59780085136697 11.934783935546875 2.452239990234375" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_9-19aec" d="M149.478271484375 420.3477962361821 C149.5691446284962 420.3477962361821 158.95651245117188 420.3477962361821 158.95651245117188 420.3477962361821 C159.22052001953125 420.3477962361821 159.43478393554688 420.5610889320766 159.43478393554688 420.8239185185994 C159.43478393554688 421.08579109067585 159.22052001953125 421.30004080101673 158.95651245117188 421.30004080101673 L149.478271484375 421.30004080101673 C149.21426391601562 421.30004080101673 149.0 421.08579109067585 149.0 420.8239185185994 C149.0 420.8239185185994 149.00730258610037 420.3477962361821 149.478271484375 420.3477962361821 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_9-19aec" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="248.9px" datasizeheight="50.0px" dataX="89.5" dataY="719.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Guardar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="248.9px" datasizeheight="50.0px" dataX="89.5" dataY="806.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Cancelar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Nombre y Apellidos:"   datasizewidth="175.2px" datasizeheight="36.0px" dataX="15.4" dataY="227.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Nombre y Apellidos:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Irene Vargas Vargas"   datasizewidth="146.8px" datasizeheight="36.0px" dataX="15.4" dataY="259.3" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Irene Vargas Vargas<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="DNI:"   datasizewidth="32.9px" datasizeheight="18.0px" dataX="15.4" dataY="295.3" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">DNI:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="215811398P"   datasizewidth="90.8px" datasizeheight="18.0px" dataX="15.4" dataY="324.3" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">215811398P</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Person circle"   datasizewidth="154.2px" datasizeheight="142.2px" dataX="249.0" dataY="214.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="154.18458557128906" height="142.17579650878906" viewBox="249.0 214.00000000000003 154.18458557128906 142.17579650878906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-19aec" d="M326.05490217531445 356.17579078674294 C368.3084670059237 356.17579078674294 403.18458032608055 324.0004795116167 403.18458032608055 285.08785063403144 C403.18458032608055 246.17515461743616 368.23384870892806 214.00000000000003 325.9802838783188 214.00000000000003 C283.8014101193771 214.00000000000003 249.0 246.17515461743616 249.0 285.08785063403144 C249.0 324.0004795116167 283.8759394695515 356.17579078674294 326.05490217531445 356.17579078674294 Z M326.05490217531445 308.87534364230055 C305.04003507639135 308.87534364230055 288.7198297221072 315.8191733798669 280.8205838136128 323.7939748363992 C270.6857121112391 313.68759932859535 264.50046740615 300.0753067733492 264.50046740615 285.08785063403144 C264.50046740615 253.53144167357698 291.849722814295 228.23127319876306 325.9802838783188 228.23127319876306 C360.1857139076528 228.23127319876306 387.6843676312825 253.53144167357698 387.7589859282781 285.08785063403144 C387.7589859282781 300.0753067733492 381.573656319405 313.68759932859535 371.36424313774495 323.8627997816183 C363.46448780654674 315.8191733798669 347.1443794851586 308.87534364230055 326.05490217531445 308.87534364230055 Z M326.05490217531445 297.60033906520266 C340.51220530430044 297.738011335311 351.7645037935486 286.3253344881048 351.7645037935486 271.61243960055276 C351.7645037935486 257.72480250508994 340.43759509337946 246.10639681122709 326.05490217531445 246.10639681122709 C311.74681946817043 246.10639681122709 300.345284384931 257.72480250508994 300.41990268192666 271.61243960055276 C300.4945128928477 286.3253344881048 311.6722011711748 297.5315066600935 326.05490217531445 297.60033906520266 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-19aec" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_1" class="selectionlist firer commentable non-processed" customid="Category 1"    datasizewidth="150.0px" datasizeheight="80.0px" dataX="15.4" dataY="435.0"   tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="scroll">\
            <div class="paddingLayer">\
              <table style="height: 100%; width: 100%;" summary="">\
                <tbody>\
                  <tr>\
                    <td >\
                      <div class="option ">Carisoprodo</div>\
                      <div class="option ">Ibuprofeno</div>\
                    </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="Medicacion"   datasizewidth="80.9px" datasizeheight="18.0px" dataX="15.4" dataY="411.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Medicacion</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_2" class="selectionlist firer commentable non-processed" customid="Category 1"    datasizewidth="247.2px" datasizeheight="80.0px" dataX="165.6" dataY="435.0"   tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="scroll">\
            <div class="paddingLayer">\
              <table style="height: 100%; width: 100%;" summary="">\
                <tbody>\
                  <tr>\
                    <td >\
                      <div class="option ">12.04.22-19.04.22, 1 vez al dia</div>\
                      <div class="option ">12.04.22-19.04.22, 3 vez al dia</div>\
                    </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Observaciones"   datasizewidth="106.7px" datasizeheight="18.0px" dataX="15.6" dataY="558.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Observaciones</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_3" class="selectionlist firer commentable non-processed" customid="Category 1"    datasizewidth="397.6px" datasizeheight="78.3px" dataX="15.2" dataY="589.0"   tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="scroll">\
            <div class="paddingLayer">\
              <table style="height: 100%; width: 100%;" summary="">\
                <tbody>\
                  <tr>\
                    <td >\
                      <div class="option ">Alergia a los gatos</div>\
                      <div class="option ">Alergia a los perros</div>\
                    </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;