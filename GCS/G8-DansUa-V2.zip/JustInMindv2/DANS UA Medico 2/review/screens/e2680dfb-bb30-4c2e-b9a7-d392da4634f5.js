var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1680642006796.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-e2680dfb-bb30-4c2e-b9a7-d392da4634f5" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Mensajeria" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e2680dfb-bb30-4c2e-b9a7-d392da4634f5-1680642006796.css" />\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="richtext manualfit firer click ie-background commentable non-processed" customid="Maria Milla"   datasizewidth="187.4px" datasizeheight="36.0px" dataX="120.0" dataY="95.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Maria Milla</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="392.0px" datasizeheight="544.0px" datasizewidthpx="391.99999999999955" datasizeheightpx="544.0" dataX="18.0" dataY="152.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rich_text_25" class="richtext manualfit firer commentable non-processed" customid="Description"   datasizewidth="220.0px" datasizeheight="78.0px" dataX="48.5" dataY="174.9" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rich_text_25_0">Buenas Jose, tengo un dolor de cabeza muy fuerte y estoy floja.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_45" class="path firer commentable non-processed" customid="Path"   datasizewidth="20.0px" datasizeheight="16.5px" dataX="38.5" dataY="239.8"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="16.5" viewBox="38.5000000000002 239.84530124334532 20.0 16.5" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_45-e2680" d="M43.470993041992415 239.84530124334538 L58.50000000000023 239.84530124334538 C58.50000000000023 249.58051402764409 52.23199462890648 256.3453012433454 44.50000000000023 256.3453012433454 L38.50000000000023 256.3453012433454 L38.50000000000023 256.0162988629743 C39.9309997558596 254.8153024640485 41.11599731445335 253.33230075506413 41.97399902343773 251.64830264715397 C43.095993041992415 249.44560489324772 43.39300537109398 244.24190005926334 43.470993041992415 239.84530124334538 Z "></path>\
            	    </defs>\
            	    <g transform="rotate(45.0 48.5000000000002 248.09530124334532)" style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_45-e2680" fill="#E5E5EA" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rich_text_23" class="richtext manualfit firer commentable non-processed" customid="Description"   datasizewidth="220.0px" datasizeheight="97.0px" dataX="153.0" dataY="279.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rich_text_23_0">Buenas Maria, eso puede ser debido a una migra&ntilde;a, mantente en cama por hoy.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_44" class="path firer commentable non-processed" customid="Path"   datasizewidth="20.0px" datasizeheight="15.0px" dataX="359.2" dataY="366.8"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="15.0" viewBox="359.19930105112206 366.8243010511221 20.0 15.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_44-e2680" d="M374.2283080091303 366.8243010511221 L359.19930105112206 366.8243010511221 C359.19930105112206 375.6744944913936 365.467306422216 381.8243010511221 373.19930105112246 381.8243010511221 L379.19930105112263 381.8243010511221 L379.19930105112263 381.52520797805755 C377.7683012952632 380.4333930699431 376.5833037366694 379.0852096981392 375.725302027685 377.5543023273118 C374.6033080091303 375.5518498237606 374.3062956800287 370.82120906559305 374.2283080091303 366.8243010511221 Z "></path>\
            	    </defs>\
            	    <g transform="rotate(315.0 369.19930105112235 374.3243010511221)" style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_44-e2680" fill="#0A84FF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 3" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="16.6px" datasizeheight="13.6px" dataX="31.4" dataY="55.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="16.637741088867188" height="13.631800651550293" viewBox="31.41406250000015 55.0 16.637741088867188 13.631800651550293" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-e2680" d="M31.41406250000015 61.82030010223389 C31.41406250000015 62.08399963378906 31.528322219848782 62.347700119018555 31.730462074279934 62.54100036621094 L37.53120183944717 68.33299922943115 C37.74220228195205 68.53519916534424 37.97070264816299 68.6318006515503 38.225602626800686 68.6318006515503 C38.77930212020889 68.6318006515503 39.18360185623184 68.23630046844482 39.18360185623184 67.70020008087158 C39.18360185623184 67.41890048980713 39.078102588653714 67.1815996170044 38.893502712249905 67.0059003829956 L36.91600275039688 65.0019006729126 L34.36718225479141 62.672800064086914 L36.41500234603897 62.79590034484863 L47.06740140914932 62.79590034484863 C47.64750242233291 62.79590034484863 48.05180311203018 62.39159965515137 48.05180311203018 61.82030010223389 C48.05180311203018 61.24020004272461 47.64750242233291 60.83590030670166 47.06740140914932 60.83590030670166 L36.41500234603897 60.83590030670166 L34.375972270965725 60.95899963378906 L36.91600275039688 58.629899978637695 L38.893502712249905 56.625969886779785 C39.078102588653714 56.4501895904541 39.18360185623184 56.212889671325684 39.18360185623184 55.93164014816284 C39.18360185623184 55.39549970626831 38.77930212020889 55.0 38.225602626800686 55.0 C37.97070264816299 55.0 37.73340272903457 55.0966796875 37.504902362823636 55.31640005111694 L31.730462074279934 61.090800285339355 C31.528322219848782 61.284199714660645 31.41406250000015 61.547800064086914 31.41406250000015 61.82030010223389 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-e2680" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext autofit firer click ie-background commentable non-processed" customid="Volver"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="55.4" dataY="52.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Volver</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_63" class="path firer commentable non-processed" customid="Person"   datasizewidth="76.4px" datasizeheight="64.2px" dataX="33.9" dataY="81.3"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="76.42345428466797" height="64.21327209472656" viewBox="33.93844604492227 81.28672799531903 76.42345428466797 64.21327209472656" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_63-e2680" d="M72.17187454472919 113.54810561838173 C82.68629661534207 113.54810561838173 91.20163576368851 106.19554818518063 91.20163576368851 97.19399288202314 C91.20163576368851 88.32988233848793 82.68629661534207 81.28672799531903 72.17187454472919 81.28672799531903 C61.70095609685224 81.28672799531903 53.09860970303397 88.4329645102149 53.142113325769884 97.26271432984112 C53.18561223419905 106.22994991678875 61.65745718842308 113.54810561838173 72.17187454472919 113.54810561838173 Z M72.17187454472919 107.53557540993214 C66.17613435609154 107.53557540993214 61.092928383115265 103.03468219120127 61.092928383115265 97.26271432984112 C61.04942947468611 91.62815208439044 66.13263544766238 87.29917991634298 72.17187454472919 87.29917991634298 C78.25461726453194 87.29917991634298 83.25081599203638 91.5594716442716 83.25081599203638 97.19399288202314 C83.25081599203638 102.96588245595765 78.21111364179602 107.53557540993214 72.17187454472919 107.53557540993214 Z M45.06089111496537 145.50000000000028 L99.23945335219896 145.50000000000028 C106.75575547023497 145.50000000000028 110.36189842224206 143.61035776755614 110.36189842224206 139.5562695267943 C110.36189842224206 130.10806582051907 95.45930533786172 117.53339412389997 72.17187454472919 117.53339412389997 C48.8842410364062 117.53339412389997 33.93844604492228 130.10806582051907 33.93844604492228 139.5562695267943 C33.93844604492228 143.61035776755614 37.54458899692935 145.50000000000028 45.06089111496537 145.50000000000028 Z M43.71403724657159 139.48747351952332 C42.6713457357091 139.48747351952332 42.28027984745461 139.21266228770438 42.28027984745461 138.59425127274082 C42.28027984745461 133.3377352777147 53.01160717186889 123.54592433234954 72.17187454472919 123.54592433234954 C91.28864300916035 123.54592433234954 102.02006461970974 133.3377352777147 102.02006461970974 138.59425127274082 C102.02006461970974 139.21266228770438 101.62905058882954 139.48747351952332 100.58601021926717 139.48747351952332 L43.71403724657159 139.48747351952332 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_63-e2680" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="330.7px" datasizeheight="45.0px" dataX="18.0" dataY="696.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Escribe aqui..."/></div></div>  </div></div></div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="61.3px" datasizeheight="50.0px" dataX="348.7" dataY="694.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Enviar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;