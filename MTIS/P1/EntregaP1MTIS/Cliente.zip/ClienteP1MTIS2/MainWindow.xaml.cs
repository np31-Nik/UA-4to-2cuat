﻿using ClienteP1MTIS2.servicioControlAccesos;
using ClienteP1MTIS2.servicioEmpleado;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ClienteP1MTIS2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ValidarNIF(object sender, RoutedEventArgs e)
        {
            servicioValidaciones.servicioValidaciones servicio = new servicioValidaciones.servicioValidaciones();
            string respuesta;
            servicio.validarNIF(validarNIF.Text,out respuesta);
            if (String.IsNullOrEmpty(respuesta))
            {
                mensajeNIF.Content = "Correcto";

            }
            else
            {
                mensajeNIF.Content = respuesta;
            }
        }

        private void ValidarIBAN(object sender, RoutedEventArgs e)
        {
            servicioValidaciones.servicioValidaciones servicio = new servicioValidaciones.servicioValidaciones();
            string respuesta;
            servicio.validarIBAN(validarIBAN.Text, out respuesta);
            if (respuesta == null)
            {
                mensajeIBAN.Content = "Correcto";

            }
            else
            {
                mensajeIBAN.Content = respuesta;
            }
        }

        private void ValidarNAFSS(object sender, RoutedEventArgs e)
        {
            servicioValidaciones.servicioValidaciones servicio = new servicioValidaciones.servicioValidaciones();
            string respuesta;
            servicio.validarNAFSS(validarNAFSS.Text, out respuesta);
            if (String.IsNullOrEmpty(respuesta))
            {
                mensajeNAFSS.Content = "Correcto";

            }
            else
            {
                mensajeNAFSS.Content = respuesta;
            }
        }

        private void CrearEmpleado(object sender, RoutedEventArgs e)
        {
            servicioEmpleado.servicioEmpleado servicio = new servicioEmpleado.servicioEmpleado();
            string respuesta;
            Empleado emp = new Empleado();
            emp.nif = empleadoNIF.Text;
            emp.nombre = empleadoNombre.Text;
            emp.apellidos = empleadoApellidos.Text;
            emp.email=empleadoEmail.Text;
            emp.naf=empleadoNAF.Text;
            emp.telefono=empleadoTelefono.Text;
            emp.valido = Convert.ToInt32(empleadoValido.Text);
            emp.usuario=empleadoUsuario.Text;
            emp.password = empleadoPassword.Text;
            emp.fechaNacimiento = DateTime.Parse(empleadoFecha.Text);
            emp.iban = empleadoIBAN.Text;
            emp.nivel = Convert.ToInt32(empleadoNivel.Text);
            emp.poblacion = empleadoPoblacion.Text;
            emp.direccion = empleadoDireccion.Text;


            servicio.nuevo(emp, out respuesta);

            if (String.IsNullOrEmpty(respuesta))
            {
                mensajeEmpleado.Content = "Empleado creado";

            }
            else
            {
                mensajeEmpleado.Content = respuesta;
            }


        }

        private void validarIBAN_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void validarNAFSS_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void empleadoUsuario_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ModificarEmpleado(object sender, RoutedEventArgs e)
        {
            servicioEmpleado.servicioEmpleado servicio = new servicioEmpleado.servicioEmpleado();
            string respuesta;
            Empleado emp = new Empleado();
            emp.nif = empleadoNIF.Text;
            emp.nombre = empleadoNombre.Text;
            emp.apellidos = empleadoApellidos.Text;
            emp.email = empleadoEmail.Text;
            emp.naf = empleadoNAF.Text;
            emp.telefono = empleadoTelefono.Text;
            emp.valido = Convert.ToInt32(empleadoValido.Text);
            emp.usuario = empleadoUsuario.Text;
            emp.password = empleadoPassword.Text;
            emp.fechaNacimiento = DateTime.Parse(empleadoFecha.Text);
            emp.iban = empleadoIBAN.Text;
            emp.nivel = Convert.ToInt32(empleadoNivel.Text);
            emp.poblacion = empleadoPoblacion.Text;
            emp.direccion = empleadoDireccion.Text;


            servicio.modificar(emp, out respuesta);

            if (String.IsNullOrEmpty(respuesta))
            {
                mensajeEmpleado.Content = "Empleado modificado";

            }
            else
            {
                mensajeEmpleado.Content = respuesta;
            }
        }

        private void BorrarEmpleado(object sender, RoutedEventArgs e)
        {
            servicioEmpleado.servicioEmpleado servicio = new servicioEmpleado.servicioEmpleado();
            string respuesta;
            servicio.borrar(empleadoNIF.Text, out respuesta);

            if (String.IsNullOrEmpty(respuesta))
            {
                mensajeEmpleado.Content = "Empleado borrado";

            }
            else
            {
                mensajeEmpleado.Content = respuesta;
            }
        }

        private void ConsultarEmpleado(object sender, RoutedEventArgs e)
        {
            servicioEmpleado.servicioEmpleado servicio = new servicioEmpleado.servicioEmpleado();
            string respuesta;

            Boolean result=false;

            Empleado emp = servicio.consultar(empleadoNIF.Text,out result, out respuesta);

            if (result)
            {
                mensajeEmpleado.Content = "Empleado obtenido";
                empleadoNIF.Text = emp.nif;
                empleadoNombre.Text = emp.nombre;
                empleadoApellidos.Text = emp.apellidos;
                empleadoEmail.Text = emp.email;
                empleadoNAF.Text=emp.naf;
                empleadoTelefono.Text=emp.telefono;
                empleadoValido.Text=emp.valido.ToString();
                empleadoUsuario.Text=emp.usuario;
                empleadoPassword.Text=emp.password;
                empleadoFecha.Text = emp.fechaNacimiento.ToString();
                empleadoIBAN.Text=emp.iban;
                empleadoNivel.Text = emp.nivel.ToString();
                empleadoPoblacion.Text=emp.poblacion;
                empleadoDireccion.Text=emp.direccion;
            }
            else
            {
                mensajeEmpleado.Content = "aaa";
            }

            
        }

        private void RegistrarPresencia(object sender, RoutedEventArgs e)
        {
            servicioControlPresencia.servicioControlPresencia servicio = new servicioControlPresencia.servicioControlPresencia();
            string respuesta;
            servicio.registrar(nifPresencia.Text, codigoSala.Text, out respuesta);
            if (String.IsNullOrEmpty(respuesta))
            {
                mensajePresencia.Content = "Presencia registrada";

            }
            else
            {
                mensajePresencia.Content = respuesta;
            }

        }

        private void EliminarPresencia(object sender, RoutedEventArgs e)
        {
            servicioControlPresencia.servicioControlPresencia servicio = new servicioControlPresencia.servicioControlPresencia();
            string respuesta;
            servicio.eliminar(nifPresencia.Text, codigoSala.Text, out respuesta);
            if (String.IsNullOrEmpty(respuesta))
            {
                mensajePresencia.Content = "Presencia eliminada";

            }
            else
            {
                mensajePresencia.Content = respuesta;
            }
        }

        private void ConsultarEmpleadoSala(object sender, RoutedEventArgs e)
        {
            servicioControlPresencia.servicioControlPresencia servicio = new servicioControlPresencia.servicioControlPresencia();
            string respuesta;
            bool result;
            String[] lista = servicio.controlEmpleadosSala(nifPresencia.Text, out result, out respuesta);
            if (String.IsNullOrEmpty(respuesta))
            {
                mensajePresencia.Content = "Obteniendo presencias";
                string listado = "";
                for (int i = 0; i < lista.Length; i++)
                {
                    listado = listado + lista[i];
                }
                listaEmpleados.Content = listado;
            }
            else
            {
                mensajePresencia.Content = respuesta;
            }
        }

        private void RegistrarAcceso(object sender, RoutedEventArgs e)
        {
            servicioControlAccesos.servicioControlAccesos servicio = new servicioControlAccesos.servicioControlAccesos();
            string respuesta;
            servicio.registrar(nifAcceso.Text, codigoSalaAcceso.Text,Convert.ToInt32(codigoDispositivo.Text), out respuesta);
            if (String.IsNullOrEmpty(respuesta))
            {
                mensajeAcceso.Content = "Acceso registrado";

            }
            else
            {
                mensajeAcceso.Content = respuesta;
            }
        }

        private void ConsultarAcceso(object sender, RoutedEventArgs e)
        {
            servicioControlAccesos.servicioControlAccesos servicio = new servicioControlAccesos.servicioControlAccesos();
            string respuesta;
            bool result;
            RegistroAccesos[] reg = servicio.consultar(nifAcceso.Text, codigoSalaAcceso.Text, Convert.ToInt32(codigoDispositivo.Text),DateTime.Parse(fechaDesde.Text),DateTime.Parse(fechaDesde.Text),out result, out respuesta);
            if (result)
            {
                mensajeAcceso.Content = "Obteniendo registros";
                string listado = "";
                for(int i = 0; i < reg.Length; i++)
                {
                    listado = listado+reg[i].nif;
                }
                listaAccesos.Content = listado;

            }
            else
            {
                mensajeAcceso.Content = respuesta;
            }
        }
    }
}
