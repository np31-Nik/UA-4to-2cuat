
/**
 * ServicioEmpleadoSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
package org.example.www.servicioempleado;

import java.sql.Date;

import org.example.www.utils.*;
/**
 * ServicioEmpleadoSkeleton java skeleton for the axisService
 */
public class ServicioEmpleadoSkeleton {

	
	private class Res{
		public boolean result = true;
		public String message = "";
	}
	
	private Res validarEmpleado(Empleado e){
		Res res = new Res();
		
		if(!Validacion.validateIBAN(e.getIban())){
			res.message = "El IBAN no es valido.";
			System.out.println("IBAN: "+e.getIban());
			res.result = false;
		}
		
		if(!Validacion.validateNAFSS(e.getNaf())){
			res.message = "El NAFSS no es valido.";
			System.out.println("NAFSS: "+e.getNaf());

			res.result = false;
		}
		
		if(!Validacion.validateNIF(e.getNif())){
			res.message = "El NIF no es valido.";
			System.out.println("NIF: "+e.getNif());

			res.result = false;
		}
			
		return res;
	}
	/**
	 * Auto generated method signature
	 * 
	 * @param modificar
	 * @return modificarResponse
	 */

	public org.example.www.servicioempleado.ModificarResponse modificar(
			org.example.www.servicioempleado.Modificar modificar) {
		ModificarResponse res = new ModificarResponse();
		Empleado emp = modificar.getEmpleado();
		
		Res validar = validarEmpleado(emp);
		
		if(validar.result){
			DAO dao = new DAO();
			Empleado bd = dao.consultar(emp.getNif());
			if(bd.getNif().isEmpty()){
				res.setResult(false);
				res.setMessage("Empleado no existe.");
			}else{
				res.setResult(dao.modificar(emp));
				if(!res.getResult()){
					res.setMessage("Error al modificar empleado");
				}else{
					res.setMessage("");
				}
			}
			
		}
		
		return res;		
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param consultar
	 * @return consultarResponse
	 */

	public org.example.www.servicioempleado.ConsultarResponse consultar(
			org.example.www.servicioempleado.Consultar consultar) {
		ConsultarResponse res = new ConsultarResponse();
		DAO dao = new DAO();
		Res r = new Res();

		Empleado emp = new Empleado();
		
		if(Validacion.validateNIF(consultar.getNif())){

			emp = dao.consultar(consultar.getNif());

			if(emp.getNif().isEmpty()){
				res.setMessage("No se ha encontrado empleado.");
				res.setResult(false);
				emp = new Empleado();
				emp.setNif("");
				emp.setNombre("");
				emp.setApellidos("");
				emp.setTelefono("");
				emp.setDireccion("");
				emp.setPoblacion("");
				emp.setEmail("");
				emp.setFechaNacimiento(new Date(0));
				emp.setNaf("");
				emp.setIban("");
				emp.setNivel(-1);
				emp.setUsuario("");
				emp.setPassword("");
				emp.setValido(0);
				res.setEmpleado(emp);
			}else{
				res.setEmpleado(emp);
				res.setResult(true);
			}
		}else{
			res.setMessage("NIF invalido");
			res.setResult(false);
			emp = new Empleado();
			emp.setNif("");
			emp.setNombre("");
			emp.setApellidos("");
			emp.setTelefono("");
			emp.setDireccion("");
			emp.setPoblacion("");
			emp.setEmail("");
			emp.setFechaNacimiento(new Date(0));
			emp.setNaf("");
			emp.setIban("");
			emp.setNivel(-1);
			emp.setUsuario("");
			emp.setPassword("");
			emp.setValido(0);
			res.setEmpleado(emp);
		}

		res.setMessage("");
		return res;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param nuevo
	 * @return nuevoResponse
	 */

	public org.example.www.servicioempleado.NuevoResponse nuevo(org.example.www.servicioempleado.Nuevo nuevo) {
		NuevoResponse res = new NuevoResponse();
		Empleado empleado = nuevo.getEmpleado();
		Res r = validarEmpleado(empleado);
		
		if(r.result){
			DAO dao = new DAO();
			
			Empleado emp = dao.consultar(empleado.getNif());
			if(!emp.getNif().isEmpty()){
				res.setMessage("Ya existe empleado con ese NIF.");
				res.setResult(false);
			}else{
				res.setResult(dao.nuevo(empleado)); 
				if(res.getResult()){
					res.setMessage("");
				}else{
					res.setMessage("Error al crear empleado.");
				}
			}
		}else{
			res.setMessage(r.message);
			res.setResult(r.result);
		}
		
		return res;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param borrar
	 * @return borrarResponse
	 */

	public org.example.www.servicioempleado.BorrarResponse borrar(org.example.www.servicioempleado.Borrar borrar) {
		BorrarResponse res = new BorrarResponse();

		if(Validacion.validateNIF(borrar.getNif())){
			DAO dao = new DAO();
			Empleado emp = dao.consultar(borrar.getNif());
			if(emp.getNif().isEmpty()){
				res.setResult(false);
				res.setMessage("Empleado no existe.");
			}else{

				res.setResult(dao.borrar(emp));
				if(!res.getResult()){
					res.setMessage("Error al borrar empleado");
				}else{
					res.setMessage("");
				}
			}
		}

		return res;	
	}

}
