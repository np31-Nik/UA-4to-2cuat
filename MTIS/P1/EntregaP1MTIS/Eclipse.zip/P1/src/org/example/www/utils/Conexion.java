package org.example.www.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
public class Conexion {
	private static final String CONTROLADOR ="org.gjt.mm.mysql.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/mtis";
	private static final String USUARIO = "root";
	
	public static Connection conectar() {
		Connection con = null;
		try {
	      Class.forName(CONTROLADOR);
	      con = DriverManager.getConnection(URL, USUARIO, "");
	    
			if (con != null) {
				System.out.println("Conexion: Conectado");
			}
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println("Conexion: No se pudo conectar a la base de datos");
			e.printStackTrace();
		}
		return con;
	}
}