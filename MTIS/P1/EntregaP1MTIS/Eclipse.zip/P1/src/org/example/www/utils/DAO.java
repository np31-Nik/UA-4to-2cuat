package org.example.www.utils;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.example.www.serviciocontrolaccesos.RegistroAccesos;
import org.example.www.servicioempleado.Empleado;
public class DAO {

	//Empleado
	
	public Empleado consultar(String nif){
		Empleado emp = new Empleado();
		emp.setNif("");
		try{
			Connection c = Conexion.conectar();
			Statement stm = c.createStatement();
			String sql = "SELECT * FROM EMPLEADOS WHERE nif='"+nif+"'";

			ResultSet rs = stm.executeQuery(sql);
			while(rs.next()){
				emp.setId(rs.getInt("id"));
				emp.setNif(rs.getString("nif"));
				emp.setNombre(rs.getString("nombre"));
				emp.setApellidos(rs.getString("apellidos"));
				emp.setTelefono(rs.getString("telefono"));
				emp.setDireccion(rs.getString("direccion"));
				emp.setPoblacion(rs.getString("poblacion"));
				emp.setEmail(rs.getString("email"));
				emp.setFechaNacimiento(rs.getDate("fechaNacimiento"));
				emp.setNaf(rs.getString("naf"));
				emp.setIban(rs.getString("iban"));
				emp.setNivel(rs.getInt("nivel"));
				emp.setUsuario(rs.getString("usuario"));
				emp.setPassword(rs.getString("password"));
				emp.setValido(rs.getInt("valido"));
			}

			c.close();			
		}catch(SQLException e){
			System.out.println("Error en consultar empleado.");
			e.printStackTrace();
		}
		return emp;
	}
	
	public boolean nuevo(Empleado emp){
		boolean res = false;
		
		try{
			Connection c = Conexion.conectar();
			String sql = "insert into empleados (nif, nombre, apellidos, direccion, poblacion, telefono, email, fechaNacimiento, naf, iban, nivel, usuario, password, valido) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement stm = c.prepareStatement(sql);
			stm.setString(1, emp.getNif());
			stm.setString(2, emp.getNombre());
			stm.setString(3, emp.getApellidos());
			stm.setString(4, emp.getDireccion());
			stm.setString(5, emp.getPoblacion());
			stm.setString(6, emp.getTelefono());
			stm.setString(7, emp.getEmail());
			stm.setDate(8, new java.sql.Date(emp.getFechaNacimiento().getTime()));
			stm.setString(9, emp.getNaf());
			stm.setString(10, emp.getIban());
			stm.setInt(11, emp.getNivel());
			stm.setString(12, emp.getUsuario());
			stm.setString(13, emp.getPassword());
			stm.setInt(14, emp.getValido());

			stm.execute();
			c.close();
			res=true;
		}catch(SQLException e){
			System.out.println("Error al crear empleado.");
			e.printStackTrace();
		}
		return res;
	}
	
	public boolean modificar(Empleado emp){
		boolean res=false;
		
		try{
			Connection c = Conexion.conectar();
			String sql = "update empleados set nombre=?, apellidos=?, direccion=?, poblacion=?, telefono=?, email=?, fechaNacimiento=?, naf=?, iban=?, nivel=?, usuario=?, password=?, valido=? where nif=?";
			
			PreparedStatement stm = c.prepareStatement(sql);
			stm.setString(1, emp.getNombre());
			stm.setString(2, emp.getApellidos());
			stm.setString(3, emp.getDireccion());
			stm.setString(4, emp.getPoblacion());
			stm.setString(5, emp.getTelefono());
			stm.setString(6, emp.getEmail());
			stm.setDate(7, new java.sql.Date(emp.getFechaNacimiento().getTime()));
			stm.setString(8, emp.getNaf());
			stm.setString(9, emp.getIban());
			stm.setInt(10, emp.getNivel());
			stm.setString(11, emp.getUsuario());
			stm.setString(12, emp.getPassword());
			stm.setInt(13, emp.getValido());
			stm.setString(14, emp.getNif());

			stm.execute();
			c.close();
			res=true;
		}catch(SQLException e){
			System.out.println("Error al modificar empleado.");
			e.printStackTrace();
		}
		
		return res;
	}
	
	public boolean borrar(Empleado emp){
		boolean res=false;
		
		try{
			Connection c = Conexion.conectar();
			String sql = "DELETE FROM empleados WHERE nif=?";
			
			PreparedStatement stm = c.prepareStatement(sql);
			stm.setString(1, emp.getNif());

			stm.execute();
			c.close();
			res=true;
		}catch(SQLException e){
			System.out.println("Error al borrar empleado.");
			e.printStackTrace();
		}
		
		return res;
	}
	
	// ControlAccesos
	public boolean registrarAcceso(String nif, String codigoSala, int codigoDispositivo){
		boolean res = false;
		try{
			Connection c = Conexion.conectar();
			String sql = "insert into registroaccesos (nif, codigoSala, codigoDispositivo, fechaHora) values (?,?,?,?)";
			
			PreparedStatement stm = c.prepareStatement(sql);
			stm.setString(1, nif);
			stm.setString(2, codigoSala);
			stm.setInt(3, codigoDispositivo);
			stm.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

			stm.execute();
			c.close();
			res=true;
		}catch(SQLException e){
			System.out.println("Error al registrar acceso.");
			e.printStackTrace();
		}
		return res;
	}
	
	public RegistroAccesos[] consultarAcceso(String nif, String codigosala, int codigodispositivo, java.util.Date date, java.util.Date date2){
		RegistroAccesos[] res = {};
		try{
			Connection c = Conexion.conectar();
			String sql = "SELECT * FROM registroaccesos WHERE nif=? AND codigoSala=? AND codigoDispositivo=? AND fechaHora between ? and ?";
			PreparedStatement stm = c.prepareStatement(sql);
			stm.setString(1, nif);
			stm.setString(2, codigosala);
			stm.setInt(3, codigodispositivo);
			stm.setDate(4, new java.sql.Date(date.getTime()));
			stm.setDate(5, new java.sql.Date(date2.getTime()));

			ResultSet rs = stm.executeQuery();

			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); 
			}

			res = new RegistroAccesos[rowcount];
			int i = 0;
			while(rs.next()){

				RegistroAccesos reg = new RegistroAccesos();
				reg.setId(rs.getInt("id"));
				reg.setNif(rs.getString("nif"));
				reg.setCodigoDispositivo(rs.getInt("codigodispositivo"));
				reg.setCodigoSala(rs.getString("codigosala"));
				
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(rs.getDate("fechahora"));
				reg.setFechaHora(calendar);
				
				res[i] = reg;
				i++;
			}

			c.close();
		}catch(SQLException e){
			System.out.println("Error al consultar acceso.");
			e.printStackTrace();
		}

		return res;
	}

	
	// Control presencia
	public boolean registrarPresencia(String nif, String codigosala) {
		boolean res = false;
		try{
			Connection c = Conexion.conectar();
			String sql = "insert into controlpresencia(nif, codigoSala) values (?,?)";
			
			PreparedStatement stm = c.prepareStatement(sql);
			stm.setString(1, nif);
			stm.setString(2, codigosala);

			stm.execute();
			c.close();
			res=true;
		}catch(SQLException e){
			System.out.println("Error al crear ControlPresencia.");
			e.printStackTrace();
		}
		return res;
	}

	public boolean borrarPresencia(String nif, String codigosala) {
		boolean res = false;
		try{
			Connection c = Conexion.conectar();
			String sql = "DELETE FROM controlpresencia WHERE nif=? AND codigosala=?";
			
			PreparedStatement stm = c.prepareStatement(sql);
			stm.setString(1, nif);
			stm.setString(2, codigosala);

			stm.execute();
			c.close();
			res=true;
		}catch(SQLException e){
			System.out.println("Error al borrar presencia.");
			e.printStackTrace();
		}
		return res;
	}

	public String[] controlEmpleadosSala(String codigosala) {
		String[] res = {};
		try{
			Connection c = Conexion.conectar();
			String sql = "SELECT * FROM controlpresencia WHERE codigoSala=?";
			PreparedStatement stm = c.prepareStatement(sql);
			stm.setString(1, codigosala);

			ResultSet rs = stm.executeQuery();

			int rowcount = 0;
			if (rs.last()) {
			  rowcount = rs.getRow();
			  rs.beforeFirst(); 
			}

			res = new String[rowcount];
			int i = 0;
			while(rs.next()){
				String reg = rs.getString("nif");
				res[i] = reg;
				i++;
			}

			c.close();
		}catch(SQLException e){
			System.out.println("Error al consultar acceso.");
			e.printStackTrace();
		}
		
		
		return res;
	}
}
