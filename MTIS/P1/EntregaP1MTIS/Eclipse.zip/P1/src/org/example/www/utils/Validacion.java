package org.example.www.utils;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validacion {

	public static boolean validateNIF(String nif) {
		if (nif.toUpperCase().startsWith("Z") || nif.toUpperCase().startsWith("X") || nif.toUpperCase().startsWith("Y"))
			nif = nif.substring(1);

		Pattern nifPattern = Pattern.compile("(\\d{1,8})([TRWAGMYFPDXBNJZSQVHLCKEtrwagmyfpdxbnjzsqvhlcke])");
		Matcher m = nifPattern.matcher(nif);
		if (m.matches()) {
			String letra = m.group(2);

			String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
			int dni = Integer.parseInt(m.group(1));
			dni = dni % 23;
			String reference = letras.substring(dni, dni + 1);
			if (reference.equalsIgnoreCase(letra)) {
				return true;
			} else {
				return false;
			}
		} else
			return false;
	}

	public static boolean validateNAFSS(String nafss) {
		String naf = nafss.trim();

		if (naf.length() != 12) {
			return false;
		}
		
		try{
			Long.valueOf(naf);
		}catch(NumberFormatException e){
			System.out.println("NAFSS no es valido.");
			return false;
		}
		return true;
	}

	public static boolean validateIBAN(String iban) {
		String cuenta = iban.trim();

		if (cuenta.length() != 24) {
			return false;
		}
		cuenta = cuenta.substring(4) + cuenta.substring(0, 4);
		StringBuilder numericAccountNumber = new StringBuilder();

		for (int i = 0; i < cuenta.length(); i++) {
			numericAccountNumber.append(Character.getNumericValue(cuenta.charAt(i)));
		}
		
		BigInteger ibanNumber = new BigInteger(numericAccountNumber.toString());
		return ibanNumber.mod(new BigInteger("97")).intValue() == 1;
	}
}
