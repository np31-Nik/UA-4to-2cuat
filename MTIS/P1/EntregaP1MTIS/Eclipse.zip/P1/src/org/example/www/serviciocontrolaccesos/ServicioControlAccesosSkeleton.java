
/**
 * ServicioControlAccesosSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
package org.example.www.serviciocontrolaccesos;

import org.example.www.utils.Validacion;

import java.sql.Date;

import org.example.www.utils.*;


/**
 * ServicioControlAccesosSkeleton java skeleton for the axisService
 */
public class ServicioControlAccesosSkeleton {

	/**
	 * Auto generated method signature
	 * 
	 * @param consultar
	 * @return consultarResponse
	 */

	public org.example.www.serviciocontrolaccesos.ConsultarResponse consultar(
			org.example.www.serviciocontrolaccesos.Consultar consultar) {
		ConsultarResponse res = new ConsultarResponse();
		
		if(Validacion.validateNIF(consultar.getNif())){
			DAO dao = new DAO();
			res.setRegistros(dao.consultarAcceso(consultar.getNif(), consultar.getCodigosala(), consultar.getCodigodispositivo(),consultar.getFechaDesde(),consultar.getFechaHasta()));

			if(res.getRegistros()!=null){
				res.setMessage("");
				res.setResult(true);
			}else{
				res.setMessage("Error al consultar acceso");
			}
			
		}else{
			res.setResult(false);
			res.setMessage("NIF no valido.");
		}
		
		return res;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param registrar
	 * @return registrarResponse
	 */

	public org.example.www.serviciocontrolaccesos.RegistrarResponse registrar(
			org.example.www.serviciocontrolaccesos.Registrar registrar) {
		RegistrarResponse res = new RegistrarResponse();
		
		if(Validacion.validateNIF(registrar.getNif())){
			DAO dao = new DAO();
			res.setResult(dao.registrarAcceso(registrar.getNif(), registrar.getCodigosala(), registrar.getCodigodispositivo()));
			if(res.getResult()){
				res.setMessage("");
			}else{
				res.setMessage("Error al registrar acceso");
			}
			
		}else{
			res.setResult(false);
			res.setMessage("NIF no valido.");
		}
		
		return res;
	}

}
