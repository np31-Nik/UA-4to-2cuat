
/**
 * ServicioControlPresenciaSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
package org.example.www.serviciocontrolpresencia;

import org.example.www.servicioempleado.Empleado;
import org.example.www.utils.DAO;
import org.example.www.utils.Validacion;

/**
 * ServicioControlPresenciaSkeleton java skeleton for the axisService
 */
public class ServicioControlPresenciaSkeleton {

	/**
	 * Auto generated method signature
	 * 
	 * @param controlEmpleadosSala
	 * @return controlEmpleadosSalaResponse
	 */

	public org.example.www.serviciocontrolpresencia.ControlEmpleadosSalaResponse controlEmpleadosSala(
			org.example.www.serviciocontrolpresencia.ControlEmpleadosSala controlEmpleadosSala) {
		ControlEmpleadosSalaResponse res = new ControlEmpleadosSalaResponse();
		DAO dao = new DAO();
		res.setUsuarios(dao.controlEmpleadosSala(controlEmpleadosSala.getCodigosala()));
		if(res.getUsuarios()!=null){
			res.setResult(true);
			res.setMessage("");
		}else{
			res.setMessage("Error en controlEmpleadosSala");
			res.setResult(false);
		}
		
		return res;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param registrar
	 * @return registrarResponse
	 */

	public org.example.www.serviciocontrolpresencia.RegistrarResponse registrar(
			org.example.www.serviciocontrolpresencia.Registrar registrar) {
		RegistrarResponse res = new RegistrarResponse();
		
		if(Validacion.validateNIF(registrar.getNif())){
			DAO dao = new DAO();
			res.setResult(dao.registrarPresencia(registrar.getNif(), registrar.getCodigosala()));
			if(res.getResult()){
				res.setMessage("");
			}else{
				res.setMessage("Error al registrar presencia");
			}
			
		}else{
			res.setResult(false);
			res.setMessage("NIF no valido.");
		}
		
		return res;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param eliminar
	 * @return eliminarResponse
	 */

	public org.example.www.serviciocontrolpresencia.EliminarResponse eliminar(
			org.example.www.serviciocontrolpresencia.Eliminar eliminar) {
		EliminarResponse res = new EliminarResponse();
		if(Validacion.validateNIF(eliminar.getNif())){
			DAO dao = new DAO();
			res.setResult(dao.borrarPresencia(eliminar.getNif(),eliminar.getCodigosala()));
			if(!res.getResult()){
				res.setMessage("Error al borrar ControlPresencia");
			}else{
				res.setMessage("");
			}
		}else{
			res.setResult(false);
			res.setMessage("NIF no valido.");
		}

		return res;
	}

}
