
/**
 * ServicioValidacionesSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.3  Built on : Jun 27, 2015 (11:17:49 BST)
 */
package org.example.www.serviciovalidaciones;

import org.example.www.utils.Validacion;

/**
 * ServicioValidacionesSkeleton java skeleton for the axisService
 */
public class ServicioValidacionesSkeleton {

	/**
	 * Auto generated method signature
	 * 
	 * @param validarIBAN
	 * @return validarIBANResponse
	 */

	public org.example.www.serviciovalidaciones.ValidarIBANResponse validarIBAN(
			org.example.www.serviciovalidaciones.ValidarIBAN validarIBAN) {
		ValidarIBANResponse res = new ValidarIBANResponse();
		
		res.setResult(Validacion.validateIBAN(validarIBAN.getIban()));
		if(res.getResult()){
			res.setMessage("");
		}else{
			res.setMessage("IBAN invalido");
		}
		
		return res;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param validarNAFSS
	 * @return validarNAFSSResponse
	 */

	public org.example.www.serviciovalidaciones.ValidarNAFSSResponse validarNAFSS(
			org.example.www.serviciovalidaciones.ValidarNAFSS validarNAFSS) {
		ValidarNAFSSResponse res = new ValidarNAFSSResponse();
		
		res.setResult(Validacion.validateNAFSS(validarNAFSS.getNafss()));
		if(res.getResult()){
			res.setMessage("");
		}else{
			res.setMessage("NAFSS invalido");
		}
		
		return res;
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param validarNIF
	 * @return validarNIFResponse
	 */

	public org.example.www.serviciovalidaciones.ValidarNIFResponse validarNIF(
			org.example.www.serviciovalidaciones.ValidarNIF validarNIF) {
		ValidarNIFResponse res = new ValidarNIFResponse();
		
		res.setResult(Validacion.validateNIF(validarNIF.getNif()));
		if(res.getResult()){
			res.setMessage("");
		}else{
			res.setMessage("NIF invalido");
		}
		
		return res;
	}

}
