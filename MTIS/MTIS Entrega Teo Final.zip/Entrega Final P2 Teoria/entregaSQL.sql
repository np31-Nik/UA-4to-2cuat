-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2023 at 01:55 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mtisteoria`
--

-- --------------------------------------------------------

--
-- Table structure for table `almacenes`
--

CREATE TABLE `almacenes` (
  `id` int(45) NOT NULL,
  `ciudad` varchar(255) NOT NULL,
  `codigo_postal` varchar(10) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `direccion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `almacenes`
--

INSERT INTO `almacenes` (`id`, `ciudad`, `codigo_postal`, `nombre`, `direccion`) VALUES
(0, 'Colombia', '1', 'Colocorreos', 'Colombia'),
(1, 'chin', '0', 'china', 'china');

-- --------------------------------------------------------

--
-- Table structure for table `coste`
--

CREATE TABLE `coste` (
  `id` int(11) NOT NULL,
  `originCp` text DEFAULT NULL,
  `destCp` text DEFAULT NULL,
  `coste` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coste`
--

INSERT INTO `coste` (`id`, `originCp`, `destCp`, `coste`) VALUES
(1, '0', '1', 25),
(2, '1', '0', 25);

-- --------------------------------------------------------

--
-- Table structure for table `envio`
--

CREATE TABLE `envio` (
  `id` int(11) NOT NULL,
  `estado` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `origen` varchar(45) DEFAULT NULL,
  `destino` varchar(45) DEFAULT NULL,
  `peso` int(11) DEFAULT NULL,
  `altura` int(11) DEFAULT NULL,
  `anchura` int(11) DEFAULT NULL,
  `longitud` int(11) DEFAULT NULL,
  `importancia` varchar(45) DEFAULT NULL,
  `coste` int(11) DEFAULT NULL,
  `idRepartidor` int(11) DEFAULT NULL,
  `fechaRecepcion` varchar(45) DEFAULT NULL,
  `entregaPrevista` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `envio`
--

INSERT INTO `envio` (`id`, `estado`, `descripcion`, `origen`, `destino`, `peso`, `altura`, `anchura`, `longitud`, `importancia`, `coste`, `idRepartidor`, `fechaRecepcion`, `entregaPrevista`) VALUES
(11, 'pendiente', 'a', 'a', 'a', 1, 1, 1, 1, '1', 25, NULL, '2023-05-23', '2023-06-22'),
(12, 'pendiente', 'h', 'h', 'h', 1, 1, 1, 1, '1', 25, NULL, '2023-05-23', '2023-06-22'),
(13, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(14, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(15, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(16, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(17, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(18, 'pendiente', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, NULL, '2023-05-23', '2023-06-22'),
(19, 'entregado', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 4, '2023-05-23', '2023-06-22'),
(20, 'enviado', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 4, '2023-05-23', '2023-06-22'),
(21, 'enviado', 'a', 'a', 'a', 2, 6, 7, 8, '1', 25, 4, '2023-05-23', '2023-06-22'),
(22, 'Esperando recogida del paquete', 'a', 'a', 'a', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(23, 'esperaCliente', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 4, '2023-05-28', '2023-06-22'),
(24, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(25, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(26, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(27, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(28, 'Esperando recogida del paquete', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 1, '2023-05-28', NULL),
(29, 'entregado', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, 4, '2023-05-28', '2023-06-22'),
(30, 'pendiente', 'Pequete', 'Colombia', 'China', 2, 6, 7, 8, '1', 25, NULL, '2023-05-23', '2023-06-22');

-- --------------------------------------------------------

--
-- Table structure for table `espaciosalmacen`
--

CREATE TABLE `espaciosalmacen` (
  `id` int(45) NOT NULL,
  `id_almacen` int(11) NOT NULL,
  `anchura` int(45) NOT NULL,
  `altura` int(45) NOT NULL,
  `longitud` int(45) NOT NULL,
  `disponible` tinyint(1) NOT NULL DEFAULT 1,
  `id_paquete` int(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `espaciosalmacen`
--

INSERT INTO `espaciosalmacen` (`id`, `id_almacen`, `anchura`, `altura`, `longitud`, `disponible`, `id_paquete`) VALUES
(1, 1, 15, 15, 15, 1, 20),
(2, 1, 30, 30, 30, 1, 21),
(3, 1, 45, 45, 45, 1, 23),
(5, 2, 10, 10, 10, 1, 29),
(6, 2, 10, 10, 10, 1, 30);

-- --------------------------------------------------------

--
-- Table structure for table `repartidor`
--

CREATE TABLE `repartidor` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellidos` varchar(45) DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `repartidor`
--

INSERT INTO `repartidor` (`id`, `nombre`, `apellidos`, `estado`) VALUES
(4, 'Ben', 'Tomasov', 'disponible'),
(5, 'Ching', 'Chong', 'disponible'),
(6, 'Juan Ramiro Gonzalo', 'Perez Fernandez de la Esquina', 'disponible');

-- --------------------------------------------------------

--
-- Table structure for table `salidaalmacen`
--

CREATE TABLE `salidaalmacen` (
  `id` int(11) NOT NULL,
  `id_almacen` int(11) NOT NULL,
  `id_paquete` int(11) NOT NULL,
  `id_repartidor` int(11) NOT NULL,
  `fechahora` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salidaalmacen`
--

INSERT INTO `salidaalmacen` (`id`, `id_almacen`, `id_paquete`, `id_repartidor`, `fechahora`) VALUES
(1, 1, 11, 1, '2023-05-24 00:00:00'),
(2, 1, 11, 1, '2023-05-24 00:00:00'),
(3, 1, 12, 1, '2023-05-24 00:00:00'),
(4, 1, 19, 1, '2023-05-24 00:00:00'),
(5, 1, 19, 1, '2023-05-24 00:00:00'),
(6, 1, 19, 1, '2023-05-24 00:00:00'),
(7, 1, 23, 1, '2023-05-24 00:00:00'),
(8, 1, 29, 1, '2023-05-24 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `seguimiento`
--

CREATE TABLE `seguimiento` (
  `id` int(11) NOT NULL,
  `codigo` text NOT NULL,
  `estado` text NOT NULL,
  `acceso` tinyint(1) NOT NULL,
  `fk_paquete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seguimiento`
--

INSERT INTO `seguimiento` (`id`, `codigo`, `estado`, `acceso`, `fk_paquete`) VALUES
(26, '4VUJMOWNSKOI', 'El agente pasara a recoger el paquete el 2023-05-26', 0, 5),
(27, 'Y1SW54D9JX4J', 'El agente pasara a recoger el paquete el 2023-05-26', 0, 6),
(28, 'QAOMDEUROQLX', 'El agente pasara a recoger el paquete el 2023-05-26', 0, 7),
(29, 'BO32YTTFMJSC', 'El agente pasara a recoger el paquete el 2023-05-26', 0, 8),
(30, 'LB3JQAMVCKR2', 'El agente pasara a recoger el paquete el 2023-05-26', 0, 9),
(31, 'G3US3IEFS78L', 'Envio entregado', 0, 10),
(32, 'QUW72Q0UN1L7', 'El paquete recibido el 2023 - 05 - 23, fecha de entrega prevista 2023-06-22', 0, 11),
(33, 'X4DKLXQAZ7IH', 'El paquete recibido el 2023 - 05 - 23, fecha de entrega prevista 2023-06-22', 0, 12),
(34, 'D6RYQU4G046H', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 13),
(35, 'QU5VPKHSQFW9', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 14),
(36, '4T6R5P1LBY3W', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 15),
(37, 'X01JQJ62ESN7', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 16),
(38, 'I3QN4RL56BJS', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 17),
(39, 'D77XKFICQ5PQ', 'El paquete recibido el 2023 - 05 - 23, fecha de entrega prevista 2023-06-22', 0, 18),
(40, 'K6YLXPH0YL8E', 'Envio entregado', 0, 19),
(41, 'VYK65Z7EHST6', 'El paquete recibido el 2023 - 05 - 23, fecha de entrega prevista 2023-06-22', 0, 20),
(42, '1076S56URELN', 'El paquete recibido el 2023 - 05 - 23, fecha de entrega prevista 2023-06-22', 0, 21),
(43, 'U78QX5V9SBE8', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 22),
(44, 'NIZM1NQGA7K1', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 23),
(45, 'OIOL9ZJ6HZMJ', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 24),
(46, 'TJM3CB357CI3', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 25),
(47, 'C2MPZ63FIYHF', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 26),
(48, 'VPKVLFO9T9IP', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 27),
(49, 'NY645SXMI7J4', 'El agente pasara a recoger el paquete el 2023-05-28', 0, 28),
(50, 'ST2EPF6YI76S', 'Envio entregado', 0, 29),
(51, 'JSRVNGR9V3E8', 'El paquete recibido el 2023 - 05 - 23, fecha de entrega prevista 2023-06-22', 0, 30);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `almacenes`
--
ALTER TABLE `almacenes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coste`
--
ALTER TABLE `coste`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `envio`
--
ALTER TABLE `envio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `espaciosalmacen`
--
ALTER TABLE `espaciosalmacen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repartidor`
--
ALTER TABLE `repartidor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salidaalmacen`
--
ALTER TABLE `salidaalmacen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seguimiento`
--
ALTER TABLE `seguimiento`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_codigo` (`codigo`) USING HASH;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coste`
--
ALTER TABLE `coste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `envio`
--
ALTER TABLE `envio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `espaciosalmacen`
--
ALTER TABLE `espaciosalmacen`
  MODIFY `id` int(45) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `repartidor`
--
ALTER TABLE `repartidor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `salidaalmacen`
--
ALTER TABLE `salidaalmacen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `seguimiento`
--
ALTER TABLE `seguimiento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
