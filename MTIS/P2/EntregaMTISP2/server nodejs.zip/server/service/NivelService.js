'use strict';
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "root",
  database: "mtis"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});

/**
 * Elimina un nivel de BD
 *
 * nivel Integer 
 * no response value expected for this operation
 **/
exports.nivelesNivelDELETE = function(nivel) {
  return new Promise(function(resolve, reject) {
    let sql = "DELETE FROM niveles WHERE nivel='"+nivel+"'";
    con.query(sql,function(err,result){
      if(result.affectedRows<1){
        resolve({statusCode:404, message:"No se encontro el nivel"});
      }else{
        resolve({statusCode:200, message:"Eliminado exitosamente"});
      }
    });
  });
}


/**
 * Devuelve información de un nivel
 *
 * nivel Integer 
 * returns Nivel
 **/
exports.nivelesNivelGET = function(nivel) {
  return new Promise(function(resolve, reject) {
    let sql = "SELECT * FROM niveles WHERE nivel='"+nivel+"'";
    con.query(sql,function(err,result){
      if(err){
        reject(err);
      }
      if(JSON.stringify(result) == "[]" || result == undefined){
        resolve({statusCode:404, message:"No se encontro el nivel"});
      }else{
        resolve({statusCode:200, result});
      }
    });
  });
}


/**
 * Actualiza un nivel en BD
 *
 * body Nivel 
 * nivel Integer 
 * no response value expected for this operation
 **/
exports.nivelesNivelPUT = function(body,nivel) {
  return new Promise(function(resolve, reject) {
    let sql = "UPDATE niveles SET descripcion='"+body.descripcion+"' WHERE nivel='"+nivel+"'";
    con.query(sql,function(err,result){
      if(err){
        resolve({statusCode:404, message:"No se encontro el nivel"});
      }else{
        resolve({statusCode:200, message:"Dispositivo modificado"});
      }
    });
  });
}


/**
 * Crea un nuevo nivel en BD
 *
 * body Nivel 
 * no response value expected for this operation
 **/
exports.nivelesPOST = function(body) {
  return new Promise(function(resolve, reject) {
    let sql = "INSERT INTO niveles (nivel,descripcion) VALUES ("+body.nivel+", '"+body.descripcion+"')";
    con.query(sql,function(err,result){
      if(err){
        resolve({statusCode:400, message:"Parametros incorrectos"});
      }else{
        resolve({statusCode:201, message:"Creado exitosamente"});
      }
    });
  });
}

