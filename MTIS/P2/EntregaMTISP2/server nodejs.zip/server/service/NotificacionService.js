'use strict';
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "root",
  database: "mtis"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    host: 'localhost',
    port: 25,
    secure: false,
});


/**
 * Notificar error
 * Envía un email a un empleado de un error
 *
 * body Notificaciones_error_body 
 * no response value expected for this operation
 **/
exports.notificacionesErrorPOST = function(body) {
  return new Promise(function(resolve, reject) {
    let sql = "SELECT * FROM empleados WHERE nif='"+body.nif+"'";
    con.query(sql,function(err,result){
      if(err){
        reject(err);
      }
      if(JSON.stringify(result) == "[]" || result == undefined){
        resolve({statusCode:404, message:"No se encontro el empleado"});
      }else{
        const message = {
          from: 'admin@example.com',
          to: result[0]['email'],
          subject: 'Error',
          text: body.error,
        };
        transporter.sendMail(message, (error, info) => {
          if (error) {
              console.error(error);
              resolve({statusCode:400,message:"Correo no se ha podido enviar"});
    
          } else {
              console.log('Email sent: ' + info.response);
              resolve({statusCode:200,message:"Correo enviado"});
          }
        });
      }
    });
  });
}


/**
 * Notificar presencia en sala
 * Envía un email a los empleados presentes en una sala indicando el nombre de la sala.
 *
 * body Notificaciones_presencia_body 
 * no response value expected for this operation
 **/
exports.notificacionesPresenciaPOST = function(body) {
  return new Promise(function(resolve, reject) {
    let sql = "SELECT codigoSala FROM salas WHERE nombre='"+body.sala+"'";
    con.query(sql,function(err,result){
      if(err){
        reject(err);
      }
      if(JSON.stringify(result) == "[]" || result == undefined){
        resolve({statusCode:404, message:"No se encontro la sala"});
      }else{
        console.log("codigoSala:"+result[0]['codigoSala']);
        let sql = "SELECT e.email FROM empleados e INNER JOIN registroaccesos r ON r.nif = e.nif WHERE r.codigoSala="+result[0]['codigoSala'];
        con.query(sql,function(err,result2){
          if(err){
            reject(err);
          }
          if(JSON.stringify(result2) == "[]" || result2 == undefined){
            resolve({statusCode:404, message:"No se encontraron empleados"});
          }else{
            for(let row of result2){
              const message = {
                from: 'admin@example.com',
                to: row['email'],
                subject: 'Presencia',
                text: body.nombre,
              };
              transporter.sendMail(message, (error, info) => {
                if (error) {
                    console.error(error);
                    resolve({statusCode:400,message:"Correo no se ha podido enviar"});
          
                } else {
                    console.log('Email sent: ' + info.response);
                    resolve({statusCode:200,message:"Correo enviado"});
                }
              });
            }
          }
        });
      }
    });
  });
}


/**
 * Notificar usuario válido
 * Envía un email a un empleado si es válido
 *
 * nif String NIF del empleado
 * no response value expected for this operation
 **/
exports.notificacionesValidacionNifGET = function(nif) {
  console.log("Validando");
  return new Promise(function(resolve, reject) {
    let sql = "SELECT * FROM empleados WHERE nif='"+nif+"'";
    con.query(sql,function(err,result){
      if(JSON.stringify(result) == "[]" || result == undefined){
        resolve({statusCode:404, message:"No se encontro el empleado"});
      }else{
        let valido = "";
        if(result[0]['valido']){
          valido="valido"
        }else{
          valido="no valido"
        }
        const message = {
          from: 'admin@example.com',
          to: result[0]['email'],
          subject: 'Validacion',
          text: valido,
        };
        transporter.sendMail(message, (error, info) => {
          if (error) {
              console.error(error);
              resolve({statusCode:400,message:"Correo no se ha podido enviar"});
    
          } else {
              console.log('Email sent: ' + info.response);
              resolve({statusCode:200,message:"Correo enviado"});
          }
        });
      }
    });
  });
}

