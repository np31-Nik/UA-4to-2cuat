'use strict';

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "root",
  database: "mtis"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});


/**
 * Elimina el dispositivo correspondiente al codigo
 * Elimina el dispositivo correspondiente al codigo especificado de BD
 *
 * codigo Long Código del dispositivo
 * no response value expected for this operation
 **/
exports.dispositivosCodigoDELETE = function(codigo) {
  return new Promise(function(resolve, reject) {
    let sql = "DELETE FROM dispositivo WHERE codigo='"+codigo+"'";
    con.query(sql,function(err,result){
      if(result.affectedRows<1){
        resolve({statusCode:404, message:"No se encontro el dispositivo"});
      }else{
        resolve({statusCode:200, message:"Eliminado exitosamente"});
      }
    });
  });
}


/**
 * Obtiene el dispositivo correspondiente al codigo
 * Devuelve el dispositivo correspondiente al codigo especificado
 *
 * codigo Long Código del dispositivo
 * returns Dispositivo
 **/
exports.dispositivosCodigoGET = function(codigo) {
  return new Promise(function(resolve, reject) {
    let sql = "SELECT * FROM dispositivo WHERE codigo='"+codigo+"'";
    con.query(sql,function(err,result){
      if(err){
        reject(err);
      }
      if(JSON.stringify(result) == "[]" || result == undefined){
        resolve({statusCode:404, message:"No se encontro el dispositivo"});
      }else{
        resolve({statusCode:200, result});
      }
    });
  });
}


/**
 * Actualiza el dispositivo correspondiente al codigo
 * Actualiza el dispositivo correspondiente al codigo especificado con la estructura proporcionada y devuelve un booleano para indicar si ha sido correcta la actualización del registro en BD.
 *
 * body Dispositivo Estructura que define un dispositivo
 * codigo Long Código del dispositivo
 * no response value expected for this operation
 **/
exports.dispositivosCodigoPUT = function(body,codigo) {
  return new Promise(function(resolve, reject) {
    let sql = "UPDATE dispositivo SET codigo='"+body.codigo+"' ,descripcion='"+body.descripcion+"' WHERE codigo='"+codigo+"'";
    con.query(sql,function(err,result){
      if(err){
        resolve({statusCode:404, message:"No se encontro el dispositivo"});
      }else{
        resolve({statusCode:200, message:"Dispositivo modificado"});
      }
    });
  });
}


/**
 * Obtiene la lista de todos los dispositivos
 * Devuelve una lista de todos los dispositivos en BD
 *
 * returns List
 **/
exports.dispositivosGET = function() {
  return new Promise(function(resolve, reject) {
    let sql = "SELECT * FROM dispositivo";
    con.query(sql,function(err,result){
      if(err){
        reject(err);
      }
      if(JSON.stringify(result) == "[]" || result == undefined){
        resolve({statusCode:404, message:"No se encontraron dispositivos"});
      }else{
        resolve({statusCode:200, result});
      }
    });
  });
}


/**
 * Crea un nuevo dispositivo en BD
 * Crea un nuevo dispositivo en BD a partir de la estructura indicada en BD
 *
 * body Dispositivo Estructura que define un dispositivo
 * no response value expected for this operation
 **/
exports.dispositivosPOST = function(body) {
  return new Promise(function(resolve, reject) {
    let sql = "INSERT INTO dispositivo (codigo,descripcion) VALUES ("+body.codigo+", '"+body.descripcion+"')";
    con.query(sql,function(err,result){
      if(err){
        resolve({statusCode:400, message:"Parametros incorrectos"});
      }else{
        resolve({statusCode:201, message:"Creado exitosamente"});
      }
    });
  });
}

