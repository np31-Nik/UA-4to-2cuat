'use strict';

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "root",
  database: "mtis"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});
/**
 * Borra una sala de la base de datos
 *
 * codigoSala Integer Código de la sala a borrar
 * no response value expected for this operation
 **/
exports.salasCodigoSalaDELETE = function(codigoSala) {
  return new Promise(function(resolve, reject) {
    let sql = "DELETE FROM salas WHERE codigoSala='"+codigoSala+"'";
    con.query(sql,function(err,result){
      if(result.affectedRows<1){
        resolve({statusCode:404, message:"No se encontro la sala"});
      }else{
        resolve({statusCode:200, message:"Eliminado exitosamente"});
      }
    });
  });
}


/**
 * Obtiene la estructura completa de una sala
 *
 * codigoSala Integer Código de la sala a consultar
 * returns Sala
 **/
exports.salasCodigoSalaGET = function(codigoSala) {
  return new Promise(function(resolve, reject) {
    let sql = "SELECT * FROM salas WHERE codigoSala='"+codigoSala+"'";
    con.query(sql,function(err,result){
      if(err){
        reject(err);
      }
      if(JSON.stringify(result) == "[]" || result == undefined){
        resolve({statusCode:404, message:"No se encontro la sala"});
      }else{
        resolve({statusCode:200, result});
      }
    });
  });
}


/**
 * Actualiza una sala en la base de datos
 *
 * body Sala Estructura completa que define una sala
 * codigoSala Integer Código de la sala a modificar
 * no response value expected for this operation
 **/
exports.salasCodigoSalaPUT = function(body,codigoSala) {
  return new Promise(function(resolve, reject) {
    let sql = "UPDATE salas SET nombre='"+body.nombre+"' ,nivel="+body.nivel+" WHERE codigoSala='"+codigoSala+"'";
    con.query(sql,function(err,result){
      if(err){
        resolve({statusCode:404, message:"No se encontro el sala"});
      }else{
        resolve({statusCode:200, message:"Dispositivo modificado"});
      }
    });
  });
}


/**
 * Crea una nueva sala en la base de datos
 *
 * body Sala Estructura que define una sala
 * no response value expected for this operation
 **/
exports.salasPOST = function(body) {
  return new Promise(function(resolve, reject) {
    let sql = "INSERT INTO salas (codigoSala,nombre,nivel) VALUES ('"+body.codigoSala+"', '"+body.nombre+"', "+body.nivel+")";
    con.query(sql,function(err,result){
      if(err){
        resolve({statusCode:400, message:"Parametros incorrectos"});
      }else{
        resolve({statusCode:201, message:"Creado exitosamente"});
      }
    });
  });
}

