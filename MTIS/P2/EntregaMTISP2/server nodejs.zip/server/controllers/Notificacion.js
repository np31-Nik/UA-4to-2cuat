'use strict';

var utils = require('../utils/writer.js');
var Notificacion = require('../service/NotificacionService');

module.exports.notificacionesErrorPOST = function notificacionesErrorPOST (req, res, next, body) {
  Notificacion.notificacionesErrorPOST(body)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.notificacionesPresenciaPOST = function notificacionesPresenciaPOST (req, res, next, body) {
  Notificacion.notificacionesPresenciaPOST(body)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.notificacionesValidacionNifGET = function notificacionesValidacionNifGET (req, res, next, nif) {
  Notificacion.notificacionesValidacionNifGET(nif)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};
