'use strict';

var utils = require('../utils/writer.js');
var Nivel = require('../service/NivelService');

module.exports.nivelesNivelDELETE = function nivelesNivelDELETE (req, res, next, nivel) {
  Nivel.nivelesNivelDELETE(nivel)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.nivelesNivelGET = function nivelesNivelGET (req, res, next, nivel) {
  Nivel.nivelesNivelGET(nivel)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.nivelesNivelPUT = function nivelesNivelPUT (req, res, next, body, nivel) {
  Nivel.nivelesNivelPUT(body, nivel)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.nivelesPOST = function nivelesPOST (req, res, next, body) {
  Nivel.nivelesPOST(body)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};
