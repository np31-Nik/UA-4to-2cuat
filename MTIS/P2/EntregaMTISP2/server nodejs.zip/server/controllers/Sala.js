'use strict';

var utils = require('../utils/writer.js');
var Sala = require('../service/SalaService');

module.exports.salasCodigoSalaDELETE = function salasCodigoSalaDELETE (req, res, next, codigoSala) {
  Sala.salasCodigoSalaDELETE(codigoSala)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.salasCodigoSalaGET = function salasCodigoSalaGET (req, res, next, codigoSala) {
  Sala.salasCodigoSalaGET(codigoSala)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.salasCodigoSalaPUT = function salasCodigoSalaPUT (req, res, next, body, codigoSala) {
  Sala.salasCodigoSalaPUT(body, codigoSala)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.salasPOST = function salasPOST (req, res, next, body) {
  Sala.salasPOST(body)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};
