'use strict';

var utils = require('../utils/writer.js');
var Dispositivo = require('../service/DispositivoService');

module.exports.dispositivosCodigoDELETE = function dispositivosCodigoDELETE (req, res, next, codigo) {
  Dispositivo.dispositivosCodigoDELETE(codigo)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.dispositivosCodigoGET = function dispositivosCodigoGET (req, res, next, codigo) {
  Dispositivo.dispositivosCodigoGET(codigo)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.dispositivosCodigoPUT = function dispositivosCodigoPUT (req, res, next, body, codigo) {
  Dispositivo.dispositivosCodigoPUT(body, codigo)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.dispositivosGET = function dispositivosGET (req, res, next) {
  Dispositivo.dispositivosGET()
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};

module.exports.dispositivosPOST = function dispositivosPOST (req, res, next, body) {
  Dispositivo.dispositivosPOST(body)
    .then(function (response) {
      utils.writeJson(res, response,response.statusCode);
    })
    .catch(function (response) {
      utils.writeJson(res, response,response.statusCode);
    });
};
