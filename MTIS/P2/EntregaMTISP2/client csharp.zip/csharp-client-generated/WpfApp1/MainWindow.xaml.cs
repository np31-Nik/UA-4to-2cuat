﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void PostSala(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                IO.Swagger.Model.Sala sala = new IO.Swagger.Model.Sala(Int32.Parse(codigoSala.Text), NombreSala.Text, Int32.Parse(NivelSala.Text));

                var json = JsonConvert.SerializeObject(sala);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync("http://localhost:8080/salas/",content);
                GetSalaErr.Content = response.StatusCode;
            }
        }

        private async void GetSala(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync("http://localhost:8080/salas/" + codigoSala.Text);
                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    var json = JObject.Parse(responseBody);
                    Console.WriteLine(responseBody);
                    NivelSala.Text = (string)json["result"][0]["nivel"];
                    NombreSala.Text = (string)json["result"][0]["nombre"];
                    GetSalaErr.Content = response.StatusCode;
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode}");
                    GetSalaErr.Content = response.StatusCode;
                }

            }
        }

        private async void PutSala(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                IO.Swagger.Model.Sala sala = new IO.Swagger.Model.Sala(Int32.Parse(codigoSala.Text), NombreSala.Text, Int32.Parse(NivelSala.Text));

                var json = JsonConvert.SerializeObject(sala);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PutAsync("http://localhost:8080/salas/" + codigoSala.Text,content);
                GetSalaErr.Content = response.StatusCode;
            }
        }

        private async void DeleteSala(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.DeleteAsync("http://localhost:8080/salas/" + codigoSala.Text);
                GetSalaErr.Content = response.StatusCode;
            }
        }

        private async void GetNivel(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync("http://localhost:8080/niveles/" + NivelNivel.Text);
                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    var json = JObject.Parse(responseBody);
                    Console.WriteLine(responseBody);
                    NivelNivel.Text = (string)json["result"][0]["nivel"];
                    DescripcionNivel.Text = (string)json["result"][0]["descripcion"];
                    NivelErr.Content = response.StatusCode;
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode}");
                    NivelErr.Content = response.StatusCode;
                }

            }
        }

        private async void PostNivel(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                IO.Swagger.Model.Nivel nivel = new IO.Swagger.Model.Nivel(Int32.Parse(NivelNivel.Text),DescripcionNivel.Text);

                var json = JsonConvert.SerializeObject(nivel);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync("http://localhost:8080/niveles/", content);
                NivelErr.Content = response.StatusCode;
            }
        }

        private async void PutNivel(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                IO.Swagger.Model.Nivel nivel = new IO.Swagger.Model.Nivel(Int32.Parse(NivelNivel.Text), DescripcionNivel.Text);

                var json = JsonConvert.SerializeObject(nivel);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PutAsync("http://localhost:8080/niveles/" + NivelNivel.Text, content);
                GetSalaErr.Content = response.StatusCode;
            }
        }

        private async void DeleteNivel(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.DeleteAsync("http://localhost:8080/niveles/" + NivelNivel.Text);
                NivelErr.Content = response.StatusCode;
            }
        }

        private async void PostDispositivo(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                IO.Swagger.Model.Dispositivo dispositivo= new IO.Swagger.Model.Dispositivo(Int32.Parse(CodigoDispositivo.Text), DescripcionDispositivo.Text);

                var json = JsonConvert.SerializeObject(dispositivo);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync("http://localhost:8080/dispositivos/", content);
                DispositivoErr.Content = response.StatusCode;
            }
        }

        private async void GetDispositivo(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync("http://localhost:8080/dispositivos/" + CodigoDispositivo.Text);
                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    var json = JObject.Parse(responseBody);
                    Console.WriteLine(responseBody);
                    DescripcionDispositivo.Text = (string)json["result"][0]["descripcion"];
                    DispositivoErr.Content = response.StatusCode;
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode}");
                    DispositivoErr.Content = response.StatusCode;
                }

            }
        }

        private async void PutDispositivo(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                IO.Swagger.Model.Dispositivo dispositivo = new IO.Swagger.Model.Dispositivo(Int32.Parse(CodigoDispositivo.Text), DescripcionDispositivo.Text);

                var json = JsonConvert.SerializeObject(dispositivo);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PutAsync("http://localhost:8080/dispositivos/" + CodigoDispositivo.Text, content);
                DispositivoErr.Content = response.StatusCode;
            }
        }

        private async void DeleteDispositivo(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.DeleteAsync("http://localhost:8080/dispositivos/" + CodigoDispositivo.Text);
                DispositivoErr.Content = response.StatusCode;
            }
        }

        private async void NotificarSala(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                IO.Swagger.Model.NotificacionesPresenciaBody notif = new IO.Swagger.Model.NotificacionesPresenciaBody(CodigoNotificarSala.Text);

                var json = JsonConvert.SerializeObject(notif);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync("http://localhost:8080/notificaciones/presencia", content);
                ErrNotificarSala.Content = response.StatusCode;
            }
        }

        private async void NotificarValido(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync("http://localhost:8080/notificaciones/validacion/" + NIFNotificarValido.Text);
                ErrValido.Content = response.StatusCode;
            }
        }

        private async void NotificarError(object sender, RoutedEventArgs e)
        {
            using (HttpClient client = new HttpClient())
            {
                IO.Swagger.Model.NotificacionesErrorBody notif = new IO.Swagger.Model.NotificacionesErrorBody(NIFNotificarError.Text,ErrorNotificarError.Text);

                var json = JsonConvert.SerializeObject(notif);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync("http://localhost:8080/notificaciones/error", content);
                ErrError.Content = response.StatusCode;
            }
        }
    }
}
