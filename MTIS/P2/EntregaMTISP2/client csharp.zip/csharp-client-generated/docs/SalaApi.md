# IO.Swagger.Api.SalaApi

All URIs are relative to *http://localhost:8000/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SalasCodigoSalaDelete**](SalaApi.md#salascodigosaladelete) | **DELETE** /salas/{codigoSala} | Borra una sala de la base de datos
[**SalasCodigoSalaGet**](SalaApi.md#salascodigosalaget) | **GET** /salas/{codigoSala} | Obtiene la estructura completa de una sala
[**SalasCodigoSalaPut**](SalaApi.md#salascodigosalaput) | **PUT** /salas/{codigoSala} | Actualiza una sala en la base de datos
[**SalasPost**](SalaApi.md#salaspost) | **POST** /salas | Crea una nueva sala en la base de datos

<a name="salascodigosaladelete"></a>
# **SalasCodigoSalaDelete**
> void SalasCodigoSalaDelete (int? codigoSala)

Borra una sala de la base de datos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SalasCodigoSalaDeleteExample
    {
        public void main()
        {
            var apiInstance = new SalaApi();
            var codigoSala = 56;  // int? | Código de la sala a borrar

            try
            {
                // Borra una sala de la base de datos
                apiInstance.SalasCodigoSalaDelete(codigoSala);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SalaApi.SalasCodigoSalaDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **codigoSala** | **int?**| Código de la sala a borrar | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="salascodigosalaget"></a>
# **SalasCodigoSalaGet**
> Sala SalasCodigoSalaGet (int? codigoSala)

Obtiene la estructura completa de una sala

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SalasCodigoSalaGetExample
    {
        public void main()
        {
            var apiInstance = new SalaApi();
            var codigoSala = 56;  // int? | Código de la sala a consultar

            try
            {
                // Obtiene la estructura completa de una sala
                Sala result = apiInstance.SalasCodigoSalaGet(codigoSala);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SalaApi.SalasCodigoSalaGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **codigoSala** | **int?**| Código de la sala a consultar | 

### Return type

[**Sala**](Sala.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="salascodigosalaput"></a>
# **SalasCodigoSalaPut**
> void SalasCodigoSalaPut (Sala body, int? codigoSala)

Actualiza una sala en la base de datos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SalasCodigoSalaPutExample
    {
        public void main()
        {
            var apiInstance = new SalaApi();
            var body = new Sala(); // Sala | Estructura completa que define una sala
            var codigoSala = 56;  // int? | Código de la sala a modificar

            try
            {
                // Actualiza una sala en la base de datos
                apiInstance.SalasCodigoSalaPut(body, codigoSala);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SalaApi.SalasCodigoSalaPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Sala**](Sala.md)| Estructura completa que define una sala | 
 **codigoSala** | **int?**| Código de la sala a modificar | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="salaspost"></a>
# **SalasPost**
> void SalasPost (Sala body)

Crea una nueva sala en la base de datos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SalasPostExample
    {
        public void main()
        {
            var apiInstance = new SalaApi();
            var body = new Sala(); // Sala | Estructura que define una sala

            try
            {
                // Crea una nueva sala en la base de datos
                apiInstance.SalasPost(body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SalaApi.SalasPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Sala**](Sala.md)| Estructura que define una sala | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
