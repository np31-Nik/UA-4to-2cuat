# IO.Swagger.Api.DispositivoApi

All URIs are relative to *http://localhost:8000/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DispositivosCodigoDelete**](DispositivoApi.md#dispositivoscodigodelete) | **DELETE** /dispositivos/{codigo} | Elimina el dispositivo correspondiente al codigo
[**DispositivosCodigoGet**](DispositivoApi.md#dispositivoscodigoget) | **GET** /dispositivos/{codigo} | Obtiene el dispositivo correspondiente al codigo
[**DispositivosCodigoPut**](DispositivoApi.md#dispositivoscodigoput) | **PUT** /dispositivos/{codigo} | Actualiza el dispositivo correspondiente al codigo
[**DispositivosGet**](DispositivoApi.md#dispositivosget) | **GET** /dispositivos | Obtiene la lista de todos los dispositivos
[**DispositivosPost**](DispositivoApi.md#dispositivospost) | **POST** /dispositivos | Crea un nuevo dispositivo en BD

<a name="dispositivoscodigodelete"></a>
# **DispositivosCodigoDelete**
> void DispositivosCodigoDelete (long? codigo)

Elimina el dispositivo correspondiente al codigo

Elimina el dispositivo correspondiente al codigo especificado de BD

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DispositivosCodigoDeleteExample
    {
        public void main()
        {
            var apiInstance = new DispositivoApi();
            var codigo = 789;  // long? | Código del dispositivo

            try
            {
                // Elimina el dispositivo correspondiente al codigo
                apiInstance.DispositivosCodigoDelete(codigo);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DispositivoApi.DispositivosCodigoDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **codigo** | **long?**| Código del dispositivo | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="dispositivoscodigoget"></a>
# **DispositivosCodigoGet**
> Dispositivo DispositivosCodigoGet (long? codigo)

Obtiene el dispositivo correspondiente al codigo

Devuelve el dispositivo correspondiente al codigo especificado

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DispositivosCodigoGetExample
    {
        public void main()
        {
            var apiInstance = new DispositivoApi();
            var codigo = 789;  // long? | Código del dispositivo

            try
            {
                // Obtiene el dispositivo correspondiente al codigo
                Dispositivo result = apiInstance.DispositivosCodigoGet(codigo);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DispositivoApi.DispositivosCodigoGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **codigo** | **long?**| Código del dispositivo | 

### Return type

[**Dispositivo**](Dispositivo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="dispositivoscodigoput"></a>
# **DispositivosCodigoPut**
> void DispositivosCodigoPut (Dispositivo body, long? codigo)

Actualiza el dispositivo correspondiente al codigo

Actualiza el dispositivo correspondiente al codigo especificado con la estructura proporcionada y devuelve un booleano para indicar si ha sido correcta la actualización del registro en BD.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DispositivosCodigoPutExample
    {
        public void main()
        {
            var apiInstance = new DispositivoApi();
            var body = new Dispositivo(); // Dispositivo | Estructura que define un dispositivo
            var codigo = 789;  // long? | Código del dispositivo

            try
            {
                // Actualiza el dispositivo correspondiente al codigo
                apiInstance.DispositivosCodigoPut(body, codigo);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DispositivoApi.DispositivosCodigoPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Dispositivo**](Dispositivo.md)| Estructura que define un dispositivo | 
 **codigo** | **long?**| Código del dispositivo | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="dispositivosget"></a>
# **DispositivosGet**
> List<Dispositivo> DispositivosGet ()

Obtiene la lista de todos los dispositivos

Devuelve una lista de todos los dispositivos en BD

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DispositivosGetExample
    {
        public void main()
        {
            var apiInstance = new DispositivoApi();

            try
            {
                // Obtiene la lista de todos los dispositivos
                List&lt;Dispositivo&gt; result = apiInstance.DispositivosGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DispositivoApi.DispositivosGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<Dispositivo>**](Dispositivo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="dispositivospost"></a>
# **DispositivosPost**
> void DispositivosPost (Dispositivo body)

Crea un nuevo dispositivo en BD

Crea un nuevo dispositivo en BD a partir de la estructura indicada en BD

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DispositivosPostExample
    {
        public void main()
        {
            var apiInstance = new DispositivoApi();
            var body = new Dispositivo(); // Dispositivo | Estructura que define un dispositivo

            try
            {
                // Crea un nuevo dispositivo en BD
                apiInstance.DispositivosPost(body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DispositivoApi.DispositivosPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Dispositivo**](Dispositivo.md)| Estructura que define un dispositivo | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
