# IO.Swagger.Model.Sala
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodigoSala** | **int?** |  | 
**Nombre** | **string** |  | 
**Nivel** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

