# IO.Swagger.Api.NivelApi

All URIs are relative to *http://localhost:8000/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**NivelesNivelDelete**](NivelApi.md#nivelesniveldelete) | **DELETE** /niveles/{nivel} | Elimina un nivel de BD
[**NivelesNivelGet**](NivelApi.md#nivelesnivelget) | **GET** /niveles/{nivel} | Devuelve información de un nivel
[**NivelesNivelPut**](NivelApi.md#nivelesnivelput) | **PUT** /niveles/{nivel} | Actualiza un nivel en BD
[**NivelesPost**](NivelApi.md#nivelespost) | **POST** /niveles | Crea un nuevo nivel en BD

<a name="nivelesniveldelete"></a>
# **NivelesNivelDelete**
> void NivelesNivelDelete (int? nivel)

Elimina un nivel de BD

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NivelesNivelDeleteExample
    {
        public void main()
        {
            var apiInstance = new NivelApi();
            var nivel = 56;  // int? | 

            try
            {
                // Elimina un nivel de BD
                apiInstance.NivelesNivelDelete(nivel);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NivelApi.NivelesNivelDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nivel** | **int?**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="nivelesnivelget"></a>
# **NivelesNivelGet**
> Nivel NivelesNivelGet (int? nivel)

Devuelve información de un nivel

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NivelesNivelGetExample
    {
        public void main()
        {
            var apiInstance = new NivelApi();
            var nivel = 56;  // int? | 

            try
            {
                // Devuelve información de un nivel
                Nivel result = apiInstance.NivelesNivelGet(nivel);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NivelApi.NivelesNivelGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nivel** | **int?**|  | 

### Return type

[**Nivel**](Nivel.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="nivelesnivelput"></a>
# **NivelesNivelPut**
> void NivelesNivelPut (Nivel body, int? nivel)

Actualiza un nivel en BD

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NivelesNivelPutExample
    {
        public void main()
        {
            var apiInstance = new NivelApi();
            var body = new Nivel(); // Nivel | 
            var nivel = 56;  // int? | 

            try
            {
                // Actualiza un nivel en BD
                apiInstance.NivelesNivelPut(body, nivel);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NivelApi.NivelesNivelPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Nivel**](Nivel.md)|  | 
 **nivel** | **int?**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="nivelespost"></a>
# **NivelesPost**
> void NivelesPost (Nivel body)

Crea un nuevo nivel en BD

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NivelesPostExample
    {
        public void main()
        {
            var apiInstance = new NivelApi();
            var body = new Nivel(); // Nivel | 

            try
            {
                // Crea un nuevo nivel en BD
                apiInstance.NivelesPost(body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NivelApi.NivelesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Nivel**](Nivel.md)|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
