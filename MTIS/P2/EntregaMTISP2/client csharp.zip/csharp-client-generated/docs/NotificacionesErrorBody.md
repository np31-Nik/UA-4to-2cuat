# IO.Swagger.Model.NotificacionesErrorBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nif** | **string** | NIF del empleado | 
**Error** | **string** | Descripción del error | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

