# IO.Swagger.Api.NotificacionApi

All URIs are relative to *http://localhost:8000/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**NotificacionesErrorPost**](NotificacionApi.md#notificacioneserrorpost) | **POST** /notificaciones/error | Notificar error
[**NotificacionesPresenciaPost**](NotificacionApi.md#notificacionespresenciapost) | **POST** /notificaciones/presencia | Notificar presencia en sala
[**NotificacionesValidacionNifGet**](NotificacionApi.md#notificacionesvalidacionnifget) | **GET** /notificaciones/validacion/{nif} | Notificar usuario válido

<a name="notificacioneserrorpost"></a>
# **NotificacionesErrorPost**
> void NotificacionesErrorPost (NotificacionesErrorBody body)

Notificar error

Envía un email a un empleado de un error

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NotificacionesErrorPostExample
    {
        public void main()
        {
            var apiInstance = new NotificacionApi();
            var body = new NotificacionesErrorBody(); // NotificacionesErrorBody | 

            try
            {
                // Notificar error
                apiInstance.NotificacionesErrorPost(body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NotificacionApi.NotificacionesErrorPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NotificacionesErrorBody**](NotificacionesErrorBody.md)|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="notificacionespresenciapost"></a>
# **NotificacionesPresenciaPost**
> void NotificacionesPresenciaPost (NotificacionesPresenciaBody body)

Notificar presencia en sala

Envía un email a los empleados presentes en una sala indicando el nombre de la sala.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NotificacionesPresenciaPostExample
    {
        public void main()
        {
            var apiInstance = new NotificacionApi();
            var body = new NotificacionesPresenciaBody(); // NotificacionesPresenciaBody | 

            try
            {
                // Notificar presencia en sala
                apiInstance.NotificacionesPresenciaPost(body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NotificacionApi.NotificacionesPresenciaPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NotificacionesPresenciaBody**](NotificacionesPresenciaBody.md)|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="notificacionesvalidacionnifget"></a>
# **NotificacionesValidacionNifGet**
> void NotificacionesValidacionNifGet (string nif)

Notificar usuario válido

Envía un email a un empleado si es válido

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NotificacionesValidacionNifGetExample
    {
        public void main()
        {
            var apiInstance = new NotificacionApi();
            var nif = nif_example;  // string | NIF del empleado

            try
            {
                // Notificar usuario válido
                apiInstance.NotificacionesValidacionNifGet(nif);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NotificacionApi.NotificacionesValidacionNifGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nif** | **string**| NIF del empleado | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
